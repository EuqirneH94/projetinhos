# Ecos dos Faróis — 001-B1.1 candidata

Não aprovada: causa original Windows e aceite real pendentes. B2 bloqueado.

Leia `EDF_001_B1_1_REPORT.md`, a RFC e `EDF_001_B1_1_WINDOWS.md`. O ZIP do jogo contém fonte, build, testes e ferramentas. Patch aplica-se somente à fonte B1 exata. Evidências distinguem falhas provocadas do incidente original, ainda não reproduzido naturalmente. Linux/Node 24.14.0: build + 50/50 testes e 20/20 SQLite aprovados.

Nenhum banco, token ou save real incluído/alterado. Não remova lock antigo vazio sem prova de manutenção exclusiva e backup. O script Windows usa bancos sintéticos próprios e gera evidências locais.

Confira SHA256SUMS.txt e o checksum externo do pacote antes de extrair/usar. Não sobreponha instalação existente. Não há migração de dados nem incremento visual B2.
