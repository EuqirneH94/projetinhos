# Evidências Alpha0.3 candidata

Todos os ensaios são Linux; nenhum arquivo comprova execução Windows ou escuta humana. A causa original WindowsB1.1 permanece desconhecida.

- release-check.log: build/typecheck e95/95 testes; baseline-check.log:60/60 antes de editar.
- original-tests-preserved.json:11 arquivos anteriores byte a byte iguais.
- journey-final-*/: quatro jornadas de protocolo público, duas facções, fabricação e captura Errante, recompensa/equipamento/desfecho/reinício, sem teleporte/grants. Contas sintéticas provisionadas offline, personagens viaWS.
- soak-final/:1800,687s reais, quatro contas; fonte backend/shared/pacotes igual no início/fim. Não é playthrough gráfico30min nem carga MMORPG.
- browser-final/: dois frames reais1280/1920 e controles640. Leia LEIA_EVIDENCIAS_BROWSER.md: captura usa pausaRAF no harness; um roteiro parcial preserva completed:false; não somar fluxos separados como E2E integral. UI-only contém somente testes/relatório sintéticos separados.
- distribution-smoke.*: pacote sem dependências de desenvolvimento, HTTP/WS, conta/legado, segunda sessão, reinício e integridade.
- compatibility.log: cópia fria sintética pela candidata/Alpha0.2 original/candidata, credencial e campos preservados.
- sqlite-repetitions.*:20/20, um teste real por execução.
- packaging.json: hashes/CRCs/189 arquivos, patch aplicado na Alpha0.2 recebida e igualdade com distribuição.
- support/: harnesses usados; layout /workspace/edf-alpha03 é deste ambiente, sem dados privados. Roteiros portáteis de destino estão no jogo e no guiaWindows.

Bancos, tokens/credenciais e referências conceituais integrais não são distribuídos. SHA256SUMS.txt verifica esta árvore; EXECUTION.json liga comandos, runtime, contagem e commit local da fonte.
