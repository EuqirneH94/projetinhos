import json,pathlib,base64
from playwright.sync_api import sync_playwright
E=pathlib.Path('/workspace/edf-alpha03/evidence/browser-final')
result={'instrumentation':'Harness pauses requestAnimationFrame after a completed 640 frame, resizes while paused, executes exactly one real application frame at each target resolution, then captures its real compositor pixels. No game, camera, save or network state injection. No FPS acceptance from these captures.','platform':'linux','renderer':'SwiftShader software','quality':'economy','errors':[],'console':[],'frames':[]}
def save():(E/'captures-result.json').write_text(json.dumps(result,indent=2))
def note(s,v=''):print(s,str(v)[:1000],flush=True)
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader','--disable-dev-shm-usage','--disable-features=CDPScreenshotNewSurface'])
 page=b.new_page(viewport={'width':640,'height':480});page.set_default_timeout(30000)
 page.add_init_script('''(()=>{const native=requestAnimationFrame.bind(window);const s={paused:false,blocked:false,queue:[]};window.__captureAnimation=s;window.requestAnimationFrame=cb=>native(t=>{if(s.paused){s.blocked=true;s.queue.push(cb);}else cb(t);});s.renderOne=()=>{s.blocked=false;const callbacks=s.queue.splice(0);for(const cb of callbacks)native(t=>cb(t));};})();''')
 page.on('pageerror',lambda e:(result['errors'].append(str(e)),note('ERROR',e),save()))
 page.on('console',lambda m:(result['console'].append(m.text[:500]),note('CONSOLE',m.text)) if m.type in ['error','warning'] else None)
 try:
  result['browser']=b.version;page.goto('http://127.0.0.1:18871/',wait_until='domcontentloaded');page.wait_for_selector('#entry-form');note('UI_READY')
  page.evaluate('''()=>{document.querySelector('#quality').click();document.querySelector('[data-faction="confluencia"]').click();const race=document.querySelector('#race');race.value='eluvios';race.dispatchEvent(new Event('change',{bubbles:true}));document.querySelector('[data-class="ressonante"]').click();document.querySelector('#nickname').value='CapturaVisual';document.querySelector('#entry-form').requestSubmit();}''')
  page.wait_for_function('()=>window.edfMetrics?.localPlayerZ===24 && window.edfMetrics.asset==="loaded" && document.querySelector("#name").textContent',polling=100,timeout=30000);note('ENTERED')
  result['metricsBeforePause']=page.evaluate('window.edfMetrics');page.evaluate('()=>{window.__captureAnimation.paused=true;}');page.wait_for_function('()=>window.__captureAnimation.blocked',polling=100);note('PAUSED')
  cdp=page.context.new_cdp_session(page)
  for w,h in [(1280,720),(1920,1080)]:
   page.set_viewport_size({'width':w,'height':h});page.evaluate('()=>window.__captureAnimation.renderOne()');page.wait_for_function('()=>window.__captureAnimation.blocked',polling=100,timeout=30000);note('REAL_FRAME',w)
   frame={'width':w,'height':h,'metrics':page.evaluate('window.edfMetrics'),'bounds':page.evaluate('''()=>Object.fromEntries(['.vitals','.world-info','.hotbar','.top-actions'].map(sel=>{let r=document.querySelector(sel).getBoundingClientRect();return [sel,{x:r.x,y:r.y,w:r.width,h:r.height,within:r.x>=0&&r.y>=0&&r.right<=innerWidth&&r.bottom<=innerHeight}]}))''')};result['frames'].append(frame);save()
   shot=cdp.send('Page.captureScreenshot',{'format':'png','fromSurface':False,'captureBeyondViewport':False});name=f'world-{w}x{h}.png';(E/name).write_bytes(base64.b64decode(shot['data']));frame['screenshot']=name;save();note('SAVED',name)
  result['completed']=True;save();note('COMPLETE')
 except Exception as e:result['failure']=str(e);result['completed']=False;save();note('FAILURE',e);raise
 finally:b.close()
