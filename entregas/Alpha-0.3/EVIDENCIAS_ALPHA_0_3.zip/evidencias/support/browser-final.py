import json,pathlib,time,traceback,base64
from playwright.sync_api import sync_playwright
E=pathlib.Path('/workspace/edf-alpha03/evidence/browser-final');E.mkdir(exist_ok=True)
result={'platform':'linux','gpu':'ANGLE SwiftShader software','quality':'economy','errors':[],'console':[],'socketTypes':[],'limitations':['No GPU or Windows validation; muted headless audio is not a human listening review.','Software screenshots can stall renderer and trigger reconnect; not a latency/performance acceptance.']}
def note(event,data=''):print(event,str(data)[:1000],flush=True)
def save(): (E/'browser-result.json').write_text(json.dumps(result,indent=2,ensure_ascii=False))
def socket(ws):
 note('WS',ws.url)
 def typ(direction,p):
  try:
   kind=json.loads(p).get('type','unknown')
   if not any(e.get('direction')==direction and e.get('type')==kind for e in result['socketTypes']):
    result['socketTypes'].append({'direction':direction,'type':kind});note('WS_'+direction,kind)
  except:pass
 ws.on('framesent',lambda p:typ('sent',p));ws.on('framereceived',lambda p:typ('received',p));ws.on('close',lambda:note('WS_CLOSE'))
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader','--disable-dev-shm-usage','--disable-features=CDPScreenshotNewSurface'])
 page=browser.new_page(viewport={'width':640,'height':480},device_scale_factor=1);page.set_default_timeout(20000)
 page.add_init_script('''(()=>{const original=requestAnimationFrame.bind(window);const state={paused:false,blocked:false,queue:[]};window.__captureAnimation=state;window.requestAnimationFrame=callback=>original(time=>{if(state.paused){state.blocked=true;state.queue.push(callback);}else callback(time)});state.resume=()=>{state.paused=false;state.blocked=false;const callbacks=state.queue.splice(0);for(const callback of callbacks)original(callback);};})()''')
 def error(e):result['errors'].append(str(e));note('PAGEERROR',e);save()
 def log(m):
  if m.type in ['error','warning']:result['console'].append({'type':m.type,'text':m.text[:1200]});note('CONSOLE_'+m.type,m.text);save()
 page.on('pageerror',error);page.on('console',log);page.on('websocket',socket)
 cdp=page.context.new_cdp_session(page)
 def metrics():return page.evaluate('window.edfMetrics')
 def shot(name):
  note('SHOT_BEGIN',name)
  page.evaluate('()=>{window.__captureAnimation.paused=true;}')
  page.wait_for_function('()=>window.__captureAnimation.blocked',polling=100)
  data=cdp.send('Page.captureScreenshot',{'format':'png','fromSurface':False,'captureBeyondViewport':False})
  (E/name).write_bytes(base64.b64decode(data['data']));page.evaluate('()=>window.__captureAnimation.resume()');result.setdefault('screenshots',[]).append(name);save();note('SHOT_SAVED',name)
 def bounds():return page.evaluate('''()=>Object.fromEntries(['.vitals','.world-info','.hotbar','.top-actions'].map(sel=>{let r=document.querySelector(sel).getBoundingClientRect();return [sel,{x:r.x,y:r.y,w:r.width,h:r.height,within:r.x>=0&&r.y>=0&&r.right<=innerWidth&&r.bottom<=innerHeight}]}))''')
 def online():page.wait_for_function('()=>document.querySelector("#network-overlay").hidden && window.edfMetrics?.localPlayerZ!==null',timeout=60000)
 try:
  result['browser']=browser.version;note('BROWSER',browser.version)
  page.goto('http://127.0.0.1:18871/',wait_until='domcontentloaded',timeout=60000)
  page.wait_for_selector('#entry-form');note('UI_READY')
  page.evaluate('''()=>{document.querySelector('#quality').click();document.querySelector('[data-faction="confluencia"]').click();const race=document.querySelector('#race');race.value='eluvios';race.dispatchEvent(new Event('change',{bubbles:true}));document.querySelector('[data-class="ressonante"]').click();document.querySelector('#nickname').value='RevisaoVisual';document.querySelector('#entry-form').requestSubmit();}''')
  page.wait_for_function('()=>document.querySelector("#name").textContent.length>0 && !document.querySelector("#hud").hidden',timeout=60000);online()
  result['initialMetrics']=metrics();result['viewportChecks']={'640':bounds()};result['controlViewport']='640x480';result['captureInstrumentation']='Render animation loop paused only after completed real frame for static capture; resumed afterwards. No camera, save, game state or protocol mutation.';save();note('ENTERED',result['initialMetrics'])
  # Functional input checks before expensive software capture.
  page.locator('#sound-button').click();note('AUDIO_OPEN');result['audioPanelVisible']=page.locator('#audio-panel').is_visible()
  page.locator('#audio-master').press('Home');note('MASTER_HOME');page.locator('#audio-master').press('ArrowRight');page.locator('#audio-music').press('Home');note('MUSIC_HOME');page.locator('#audio-music').press('ArrowRight')
  result['audioMasterAfterKeyboard']=page.locator('#audio-master').input_value();result['audioMusicAfterKeyboard']=page.locator('#audio-music').input_value()
  page.locator('#reduced-effects').check();note('REDUCED_CHECKED');page.wait_for_function('()=>window.edfMetrics?.reducedEffects===true');result['reducedEffectsMetrics']=metrics();result['audioState']=page.locator('#audio-state').inner_text();page.locator('#audio-close').click();save();note('AUDIO_TESTED')
  page.locator('#bag-button').click();result['bagVisible']=page.locator('#bag').is_visible();result['bagFocus']=page.evaluate('document.activeElement?.id');page.keyboard.press('Escape');result['bagClosedByEscape']=not page.locator('#bag').is_visible();result['focusRestored']=page.evaluate('document.activeElement?.id');save();note('BAG_TESTED')
  # Take clean spawn captures after functional controls. No camera/save/world mutation.
  page.set_viewport_size({'width':1280,'height':720});page.wait_for_function('()=>document.querySelector("#world").getBoundingClientRect().width===1280');page.locator('#world').focus();result['viewportChecks']['1280']=bounds();shot('world-1280x720.png');online()
  page.set_viewport_size({'width':1920,'height':1080});page.wait_for_function('()=>document.querySelector("#world").getBoundingClientRect().width===1920');result['viewportChecks']['1920']=bounds();result['metrics1920']=metrics();save();shot('world-1920x1080.png');online()
  page.set_viewport_size({'width':640,'height':480});page.wait_for_function('()=>document.querySelector("#world").getBoundingClientRect().width===640')
  page.locator('#world').focus();result['beforeMovement']=metrics();save()
  page.keyboard.down('w')
  try:page.wait_for_function('()=>window.edfMetrics?.localPlayerZ < 16',timeout=20000)
  finally:page.keyboard.up('w')
  page.keyboard.down('a')
  try:page.wait_for_function('()=>window.edfMetrics?.localPlayerX < -3',timeout=15000)
  finally:page.keyboard.up('a')
  result['afterMovement']=metrics();save();note('MOVED',result['afterMovement'])
  page.keyboard.press('e');page.wait_for_selector('#dialog:not([hidden])',timeout=10000);result['interactionVisible']=page.locator('#dialog').is_visible();result['dialogueText']=page.locator('#dialog-content').inner_text();result['dialogueFocus']=page.evaluate('document.activeElement?.dataset.dialogAction');save();note('DIALOGUE_TESTED')
  page.keyboard.press('Escape');page.locator('#skill-cleave').hover();result['skillTooltipVisible']=page.locator('#skill-tooltip').is_visible();result['hoverMetrics']=metrics();save();shot('ability-hover.png')
  result['finalMetrics']=metrics();result['completed']=True;save();note('COMPLETED')
 except Exception as ex:
  result['failure']=str(ex);result['completed']=False;save();note('FAILED',str(ex));note('TRACEBACK',traceback.format_exc())
  try:note('DOM',page.evaluate('({error:document.querySelector("#entry-error")?.textContent,net:document.querySelector("#network-text")?.textContent,name:document.querySelector("#name")?.textContent,metrics:window.edfMetrics})'))
  except:pass
  raise
 finally:browser.close()
