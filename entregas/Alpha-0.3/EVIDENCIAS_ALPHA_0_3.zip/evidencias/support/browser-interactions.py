import json,pathlib,traceback
from playwright.sync_api import sync_playwright
E=pathlib.Path('/workspace/edf-alpha03/evidence/browser-final');r={'viewport':'640x480','renderer':'SwiftShader software','platform':'linux','errors':[],'console':[],'steps':[]}
def note(k,v=''):print(k,str(v)[:1000],flush=True)
def save():(E/'interactions-result.json').write_text(json.dumps(r,indent=2,ensure_ascii=False))
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader','--disable-dev-shm-usage'])
 page=b.new_page(viewport={'width':640,'height':480});page.set_default_timeout(15000)
 page.on('pageerror',lambda e:(r['errors'].append(str(e)),save()))
 page.on('console',lambda m:r['console'].append(m.text[:500]) if m.type in ['error','warning'] else None)
 try:
  r['browser']=b.version;page.goto('http://127.0.0.1:18871/',wait_until='domcontentloaded');page.wait_for_selector('#entry-form')
  page.evaluate('''()=>{document.querySelector('#quality').click();document.querySelector('[data-faction="confluencia"]').click();const race=document.querySelector('#race');race.value='eluvios';race.dispatchEvent(new Event('change',{bubbles:true}));document.querySelector('[data-class="ressonante"]').click();document.querySelector('#nickname').value='InteracaoReal';document.querySelector('#entry-form').requestSubmit();}''')
  page.wait_for_function('()=>window.edfMetrics?.localPlayerZ===24 && !document.querySelector("#hud").hidden',polling=100);r['beforeMovement']=page.evaluate('window.edfMetrics');save();note('ENTERED',r['beforeMovement'])
  page.locator('#world').focus();page.keyboard.down('w')
  try:page.wait_for_function('()=>window.edfMetrics.localPlayerZ<16',polling=100,timeout=15000)
  finally:page.keyboard.up('w')
  r['afterW']=page.evaluate('window.edfMetrics');save();note('AFTER_W',r['afterW'])
  page.keyboard.down('a')
  try:page.wait_for_function('()=>window.edfMetrics.localPlayerX < -3',polling=100,timeout=10000)
  finally:page.keyboard.up('a')
  r['afterA']=page.evaluate('window.edfMetrics');save();note('AFTER_A',r['afterA'])
  page.keyboard.press('e');page.wait_for_selector('#dialog:not([hidden])',timeout=10000)
  r['dialogueVisible']=page.locator('#dialog').is_visible();r['dialogueText']=page.locator('#dialog-content').inner_text();r['dialogueFocus']=page.evaluate('document.activeElement?.dataset.dialogAction');save();note('DIALOGUE',r['dialogueText'])
  page.keyboard.press('Escape');page.locator('#skill-cleave').hover();r['tooltipVisible']=page.locator('#skill-tooltip').is_visible();r['tooltipText']=page.locator('#skill-tooltip').inner_text();save();note('TOOLTIP',r['tooltipText'])
  r['completed']=True;save();note('COMPLETE')
 except Exception as e:r['failure']=str(e);r['completed']=False;save();note('FAILURE',str(e));raise
 finally:b.close()
