# UI/UX — candidata Alpha 0.3

O HUD foi refinado na cópia de trabalho Alpha 0.2 preservada, sem editar saves, esquema SQLite ou APIs existentes. A composição é uma proposta a avaliar pelo usuário, não um layout canônico aprovado.

## Alterações

- Moldura de vida/energia com nomes visíveis; alvo com forma e texto de relação hostil/aliado, distância em metros e estado.
- Mapa menor, recolhível e com marcadores de criaturas quadrados distintos dos viajantes circulares. Objetivo compacto na lateral. Centro do combate livre de avisos de rotina.
- Barra de ações com nomes maiores, atalho, custo, recarga numérica e motivo resumido de indisponibilidade. Ícones de arco, nota, escudo, área e cura distinguem os kits. Tooltip informa alcance, origem/raio da área e conjuração; prévia no mundo usa callback integrado pelo `main.ts`.
- Avisos repetidos agregados com contador; até três notificações em canto inferior esquerdo, preservando a exibição de erros novos.
- Ajuda, mochila, conversa, áudio e recuperação com isolamento de foco (`inert`) e retorno ao controle de origem. Tab mantém navegação nativa e não aciona seleção de alvo. Escape fecha painéis opcionais. Queda/desconexão substituem painéis sem bloquear os controles de recuperação.
- Voz com volume independente; preferência local para reduzir efeitos e movimento, incluindo a configuração inicial do sistema. Áudio e geometria da cena são integrados por seus responsáveis.
- Ofício e companheiro em painéis sob demanda na mochila; contexto para bancada e progresso de vínculo no cast. A interface solicita as operações e aguarda o servidor; não deduz sucesso nem consome itens localmente.

## Referências consultadas

Inspeção visual de `Ecos dos Faróis - Dois Caminhos, Um Destino.png` e `Ecos dos Faróis - Os Quatro Povos.png`, além do checklist documental `REQUISITOS_IMPLEMENTACAO.md`. Usados como direção de contraste entre tinta escura, metal dourado e ressonância arcana. As pranchas históricas não substituem os nomes/regras atuais da Bíblia; nenhuma imagem das pranchas foi copiada para o jogo.

## Arquivos

- `client/src/ui.ts`
- `client/src/style.css`
- `client/src/ui-state.ts` (novo; dicas somente informativas)
- `tests/ui-accessibility.test.ts` (novo; oito regressões)

## Verificação executada

- `npm run typecheck`: aprovado, Linux / Node 24.14.0.
- `node --import tsx --test tests/ui.test.ts tests/ui-accessibility.test.ts`: **10/10 aprovados**, incluindo os dois testes anteriores preservados. Registro em `ui-tests.log`.
- Inspeção Chromium isolada do HUD em 1280×720 e 1920×1080: sem erros JavaScript. Arquivos `hud-fixture-*.png`, `settings-fixture-1280.png`, `ui-layout.json`. Esses quadros usam snapshot sintético e fundo plano para revisar a interface; **não comprovam gameplay ou WebGL**. As evidências integradas e o build final pertencem à verificação principal.

## Pendências e limites

- Aprovação estética do usuário e verificação Windows/GPU real; não homologados nesta tarefa de UI.
- Locução real continua dependente de gravações com procedência; volume de voz não prova dublagem entregue.
- O tema utiliza fontes do sistema e símbolos vetoriais originais simples; não equivale a uma coleção final de ícones ilustrados.
- Dicas locais podem ficar defasadas durante latência; toda autorização e efeito permanecem validados pelo servidor, inclusive distância, energia e inventário.
- Nomes/receita/tuning de ofício e companheiro continuam experimentais conforme o catálogo; nada foi declarado cânone definitivo.
