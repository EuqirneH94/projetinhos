# Ecos dos Faróis — entrega CODEX001-B1

## Resultado e autorização

Fundação implementada e validada no **Linux**. O usuário informou aceite Windows da baseline001-B0.1(build21/21,20 repetições,SQLite e controles). **B1 ainda depende de aceite Windows real**. Nenhuma migração destrutiva ou importação de banco legado foi executada.

O usuário autorizou nesta conversa: recusar segunda sessão e manter a primeira; permitir16 combinações raça×classe como metadados, com habilidades/equipamentos específicos por implementar. Essas decisões complementam a GDB1.1.0 para o escopoB1, sem editar o pacote documental recebido ou atribuir escolhas a saves antigos.

Baseline: ZIP001-B0.1 SHA256 `53ef43e57d8f601c5cf7a25034241e7f991084cda21e2108344cda78c69d10f2`. Código recebido em ZIP sem Git remoto; não se inventou branch/commit. O projeto calculadora e os artefatos anteriores ficaram intactos.

## O que mudou

- AccountStore separado, opt-in por ACCOUNTS_DB_PATH, com identidade SQLite própria. Nenhuma coluna/tabela/user_version do Store legado alterada. Bootstrap lê o application_id em modo readonly e recusa banco de contas em DB_PATH; AccountStore recusa banco legado/versão desconhecida como contas antes de WAL/DDL. Caminhos iguais são recusados. Caminhos físicos normalizados e hardlinks recusados; lock exclusivo impede abrir o mesmo banco de contas em dois mundos.
- Contas de teste provisionadas offline, tokens aleatórios de32bytes/base64url, hashSHA256 e expiração fixa30dias. Falha ao entregar credencial reverte a transação. Não há criação pública de conta, senha, login de produção ou recuperação automática.
- Até oito personagens por conta, ambos os lados, slots/combinações com constraints e criação transacional. Vigília:Valdários/Kordrânios; Confluência:Elúvios/Náquiros. Catálogo Sentinela/Arcanista/Errante/Ressonante e16 pares persistidos como metadados. A criação não aceita saldo,save,accountId ou atributos livres do cliente.
- Carteira, inventário, missão e progresso continuam no PlayerSave de cada personagem. Conta guarda identidade/credenciais; não há carteira/banco compartilhado ou transferência. Personagem alheio não é listável/selecionável pela API de conta.
- Lease exclusiva por conta: duas abas podem autenticar/listar; só uma entra no jogo. Segunda entrada é recusada, sem expulsar a primeira. UUID de lease impede escrita/liberação antiga; ações revalidam credencial e lease. Revogação/expiração fecha jogo. Token legado não é concedido a personagens de conta; não há bypass por resume/join na mesma conexão.
- Novas mensagens WS de login/lista/criação/seleção/saída e tela simples de laboratório. A seleção usa o mesmo mundo, câmera, combate, missão, inventário e áudio existentes. HUD indica KIT DO PROTÓTIPO; isso **não implementa kits de classe nem inícios canônicos de facção**. Credencial de conta fica apenas na sessão da aba e nunca em URL/localStorage/log.
- Roteamento de persistência por identidade, sem escrever personagens novos em players/sessions legados. Erro real de gravação fecha entradas e sinaliza health503. Recusas de domínio não derrubam o servidor. Startup inválido/bind ocupado libera recursos da nova camada.

## Preservação comprovada

Os21 testes legados estão byte a byte intactos, incluindo a correção001-B0.1. Store v1,configurações de itens/habilidades/movimento,UI legada,módulos de áudio,package.json e lockfile não mudaram. Em game.ts só o nome do tipo de mensagem foi separado; após substituir LegacyClientMessage→ClientMessage, o arquivo é idêntico à baseline. Nenhuma lógica nova de combate/equipamento/quest foi inventada.

PlayerSave não ganhou facção/raça/classe presumidas. Nenhum banco real do usuário foi recebido/aberto. Bancos dos testes são sintéticos em diretórios temporários. O ZIP não contém DB,sidecars,lock,credenciais,node_modules ou.git. A versão do protótipo permanece0.1.0, com incrementoB1 identificado nos arquivos/docs; não houve atualização desnecessária de dependências.

## Execução real

Ambiente: Linux-6.18.44-x86_64-with-glibc2.41; Node24.19.0/npm11.9.0. Build/typecheck aprovados, incluindo páginas de jogo e contas. Warning Vite >500kB permanece conhecido, sem ajuste para ocultar aviso.

| Verificação | Resultado real |
|---|---|
| npm ci congelado | PASS, sem alterar lock/TLS/integridades |
| Build/typecheck final | PASS |
| Suíte completa | **40/40**,0 falhos/cancelados/ignorados |
| Novos testes de contas/personagens | **19/19** |
|21 testes originais | Preservados e incluídos nos40 |
| SQLite legado isolado |20/20 repetições aprovadas |
| Ordem cliente-primeiro | PASS na correção B0.1 preservada |
| Gravação perdida no controle legado | **FAIL esperado0≠316**, continua detectando perda real |
| Falha real de gravação B1 | Teste PASS por verificar fechamento1011,health503 e ausência de confirmação durável |
| Oitavo/nono concorrente | Uma criação válida e uma recusa, sem nono registro |
| Seleções simultâneas na conta | Uma lease, outra recusa; conta distinta permitida |
| SQLite novo | Reabertura,backup frio restaurado,integrity_check=ok e FK sem erros |
| Recusa de banco legado como contas | Bytes idênticos; sem criação/alteração de schema v1 |
| Retorno a B0.1 | Módulo Store da baseline real leu save v1; banco de contas/restauração separado preservados |
| CLI e bootstrap reais | Provisionamento sem imprimir token; overwrite recusado; HTTP200; SIGINT exit0/lock liberado; caminhos trocados recusados sem alterar bytes |
| Chromium154 headless/SwiftShader | Criou nas duas facções,renderizou cena,movimento observado,segunda sessão recusada,zero pageerrors |
| Patch de fonte | Aplicação e reversão verificadas byte a byte |
| ZIP final |83 hashes internos,0 divergências;84 membros; conteúdo conferido |

Os testes novos cobrem auth/hash/expiração,limite/owner,16 pares sem bônus,forja de facção/classe/campos,rollback de escrita/credencial,leases/concorrência,backup/reinício,lock/hardlink,versão futura,revogação,feature desligada e falha de bind/storage. Há sinais de falha de persistência impressos intencionalmente pelos testes negativos; avaliar o resultado documentado e suas asserções, sem mascarar falhas.

## Falha intermediária do verificador de navegador

A primeira sonda esperava visibilidade geométrica do container #hud, cujos filhos são absolutos e cujo próprio retângulo pode ser zero mesmo quando hidden já foi removido. Retornou timeout e foi preservada em browser.log,exit1. Corrigiu-se a sonda para verificar o elemento visível #name e o estado do jogo, sem mudar CSS para forçar aprovação. A repetição browser-corrected passou e preserva screenshots de contas/jogo. Não se apresentou a tentativa inicial como sucesso. Não houve teste Windows,medição de FPS/carga ou audição humana; SwiftShader não é hardware de referência.

## Backup,rollback e migração futura

RFC_001_B1.md foi registrada antes da implementação compatível. Nenhuma migração destrutiva foi necessária. Backup frio/restauração e leitura v1 pela baseline foram exercitados com fixtures. Para dados reais, parar serviços, identificar DB_PATH real,preservar original+sidecars consistentes,calcular hashes e testar cópia restaurada; nunca copiar só banco ativo ou apagar lock sem confirmar processo encerrado.

Rollback de fonte: pararB1,guardar os dois bancos,voltar à pasta/configuraçãoB0.1 original. Dados novos de contas ficam no arquivo separado para retomadaB1; **não são convertidos para v1**. Restaurar backup antigo após novas escritas pode perder progresso posterior; não prometer fusão/retorno sem plano específico. O guia Windows detalha backup em pasta nova e restauração em cópia, sem sobrescrever originais.

Uma futura migração de saves exigirá autorização específica,checkpoint frio,ledger,staging,validadores e mapa de conteúdo aprovado,além de associação explícita pelo titular. Nada infere que espada legada é Sentinela ou Alvor é Vigília/Valdário. A validação integral de JSON PlayerSave permanece trabalho específico; a camada atual aceita body criado pelo backend, não importação livre de save.

## Limites explícitos

Conta/autenticação é local e fechada de teste; sem operação pública/cluster. Um mundo por arquivo de contas,lock órfão exige diagnóstico manual. Nomes seguem labels do protótipo,sem política global de unicidade aprovada; exclusão/recuperação7dias não é exposta. Metadados de povos/classes não incluem corpos,rigs,habilidades,talentos ou permissões finais de equipamento. A área comum é laboratório, não começo narrativo válido das facções.

Não implementados: guildas completas,mercados,bancos compartilhados,montarias,voo,dungeons,editor corporal avançado,Unreal ou migração de bancos. Não declarar40 testes como prova de capacidade32 ou segurança de produção. Aceite Windows é futuro, separado do aceite já informado paraB0.1.

## Arquivos de fonte no patch

O patch não contém build/client/dist nem manifesto de distribuição; esses são derivados do build real. No ZIP de jogo, o build real substitui os derivados antigos e remove assets obsoletos pelo fluxo normal de Vite. README/docs novas entram na fonte. Nenhuma edição manual de assets compilados foi feita.

| Arquivo | Mudança |
|---|---|
|README.md|modified|
|client/accounts.html|added|
|client/src/accounts.ts|added|
|client/src/main.ts|modified|
|client/src/network.ts|modified|
|docs/ACCOUNTS_B1.md|added|
|docs/RFC_001_B1.md|added|
|scripts/account-admin.ts|added|
|server/src/accounts.ts|added|
|server/src/game.ts|modified|
|server/src/index.ts|modified|
|server/src/protocol.ts|modified|
|server/src/server.ts|modified|
|shared/identity.ts|added|
|shared/types.ts|modified|
|tests/accounts-network.test.ts|added|
|tests/accounts.test.ts|added|
|vite.config.ts|modified|

## Entregas e integridade

ZIP jogo atualizado: `Reinos_de_Nexo_v0_1_0_EDF_001_B1.zip`,SHA256 `c41c6613f71cda45404afe8e564cb17b91d44f6dcbbebe4f049201a8a57e3962`. Patch de fonte:EDF_001_B1.patch. ZIP de evidências contém relatório,RFC,guia Windows,checkpoint dos arquivos alterados,logs,screenshots e sondas. Arquivo externo EDF_001_B1_SHA256SUMS.txt confere os artefatos. Pacote completo agrega tudo para download único,sem dados privados.

A fonte original não era checkout Git. Checkpoints e diffs identificam a baseline porSHA,sem alegar histórico remoto. Aplicar patch em cópia exata com `git apply --check`; testar reversão com `--reverse --check`; executar build para regenerar derivados. O manifesto da baseline não confere fonte alterada após patch: usar ZIP com manifesto novo para validação de distribuição,sem alterar checksum de dependências.

Comandos/durações/saídas completos em evidence/*commands.json e logs. O diretório validation contém as dependências efêmeras; a distribuição foi verificada e teve suíte executada com instalação congelada. Artefatos de teste e credenciais não integram a entrega.
