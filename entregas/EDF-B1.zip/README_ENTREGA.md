# Entrega CODEX001-B1

1. Extraia o pacote completo. Ele contém o ZIP do jogo, o ZIP de evidências, o patch, os hashes, a RFC, o relatório e o guia Windows.
2. Confira EDF_001_B1_SHA256SUMS.txt. O ZIP de jogo correto é Reinos_de_Nexo_v0_1_0_EDF_001_B1.zip.
3. Siga EDF_001_B1_WINDOWS.md para extrair o jogo em pasta nova, validar83 hashes, build e40/40 e provisionar duas contas locais. Nenhum banco do usuário é incluído/importado.
4. A RFC está em RFC_001_B1.md e também no jogo em docs/RFC_001_B1.md. As duas decisões do usuário paraB1 são recusar segunda sessão e permitir16 pares raça×classe como metadados.

Resultado real Linux:40/40,19 novos+21 preservados;20 repetições SQLite;controle negativo preservado;browser/backup/rollback/CLI aprovados. WindowsB1 precisa de execução real e aceite. O aceite Windows informado pelo usuário refere-se à baselineB0.1.

## Evidência final versus iterações preservadas

Arquivos autoritativos desta distribuição: evidence/final-package-integrity.json, final-distribution-integrity.log, final-artifact-suite.log e cli-result.json. Hash final do jogo começa com c41c6613. Arquivos package-integrity.json, artifact-commands.json e suites37/39 pertencem a rascunhos de desenvolvimento; foram preservados para transparência, não descrevem o ZIP final. O log browser.log guarda falha inicial do verificador; browser-corrected.log e screenshots são da repetição corrigida, descrita no relatório.

O patch é de fonte,sem derivados. Alterações compiladas/manifesto foram gerados pelo build real e empacotamento no ZIP. Checkpoint contém versões antigas dos arquivos alterados,sem banco ou credenciais. Para aplicação/reversão use a baseline exata com git apply --check; testes de forward/reverse foram realizados. Em instalação com mudanças próprias, revisar conflitos antes de aplicar; o caminho recomendado é o ZIP em pasta nova.

Sondas externas não integram o runtime. persistence-control.mts só deve ser carregado no teste isolado conforme o guia; lost-write deve falhar. Scripts de browser/rollback referem layout local de auditoria com diretórios irmãos source/validation; os comandos correspondentes e cwd estão nos logs. O jogo usa somente dependências do próprio lockfile; Playwright/Chromium de auditoria não viram dependência do projeto.

Conta de teste não é auth pública. Classes e povos são metadados no laboratório: kit do protótipo preservado,sem kits novos ou inícios canônicos. Nenhuma migração destrutiva,exclusão,mercado,guilda,montaria,dungeon ou Unreal implementada. Guardar bancos e chaves privados; não enviá-los no aceite.
