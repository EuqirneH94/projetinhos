# Rastreabilidade do incremento autorizado

| Requisito | Implementação/evidência | Resultado e limite |
|---|---|---|
|1Preservar protótipo | Store/config/movimento/UI/áudio/dependências preservados porSHA;game.ts só separa tipo;21 testes originais intactos | PASS noLinux;mesma cena/combate/quest/inventário/áudio |
|2Conta e até8personagens | accounts.ts:accounts/characters,slots1..8,FK,UNIQUE eBEGIN IMMEDIATE;testes de último slot concorrente | PASS,oitavo aceito e nono recusado |
|3Duas facções por conta | shared/identity.ts eUI de contas;criação em ambas no domínio/navegador | PASS como metadados,no laboratório |
|4Povos exclusivos | Catálogo eCHECK SQLite,faction/race revalidados no servidor | PASS inclusive par forjado |
|5Quatro classes | IDs e16pares autorizados expressamente nesta conversa;classes persistem emCharacterInfo | PASS de metadados;sem kits/bônus novos |
|6Uma sessão de jogo por conta | Lease UUID por conta,segunda entrada recusada,lock físico por banco,ações revalidadas | PASS sequencial/concorrente e liberação antiga;um processo de mundo porarquivo |
|7Dados separados | Conta:id/credencial;personagem:metadata+PlayerSave(carteira/inventário/quest) | PASS,personagem distinto mantém saldo0enquanto outro tem47 |
|8Saves/backup/rollback | DB separado,opt-in,guardas readonly,backupfrio restaurado eStore B0.1real lendo v1 | PASS em fixtures;nenhuma migração real executada |
|9Permissões servidor | Parser estrito,accountId obtido da credencial,ownership/lease/limite/combinação,revogação e falha de storage | PASS;sem auth/cadastro público |
|10Testes reais |19novos+21originais,build,repetições,browser,CLI,SQLite e pacote |40/40Linux;aceiteWindowsB1pendente |

RFC e riscos foram registrados antes das mudanças compatíveis. Dados existentes nunca foram classificados automaticamente nem convertidos. Guildas,mercados,montarias,voo,dungeons,editorcorporal eUnreal estão ausentes. Classe/povo selecionados aqui não provam seus sistemas finais da GDB; a autorização atual trata a fundação e os metadados. Recuperação7dias e inícios canônicos exigem próximos incrementos específicos,sem exclusão/migração implícita.
