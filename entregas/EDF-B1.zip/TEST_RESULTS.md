# Resultados001-B1

Resultado final: build e40/40 noLinux;19 testes novos e21 originais. Windows B1 não executado. Browser/backup/CLI descritos no relatório; falha inicial do verificador preservada.

| Registro | Nome | Exit | Duração s |
|---|---|---:|---:|
|acceptance-commands.json|acceptance-build|0|4.425|
|acceptance-commands.json|acceptance-accounts|0|1.076|
|acceptance-commands.json|acceptance-suite|0|1.833|
|acceptance-commands.json|legacy-repeat-01|0|0.264|
|acceptance-commands.json|legacy-repeat-02|0|0.239|
|acceptance-commands.json|legacy-repeat-03|0|0.236|
|acceptance-commands.json|legacy-repeat-04|0|0.241|
|acceptance-commands.json|legacy-repeat-05|0|0.244|
|acceptance-commands.json|legacy-repeat-06|0|0.256|
|acceptance-commands.json|legacy-repeat-07|0|0.251|
|acceptance-commands.json|legacy-repeat-08|0|0.236|
|acceptance-commands.json|legacy-repeat-09|0|0.241|
|acceptance-commands.json|legacy-repeat-10|0|0.24|
|acceptance-commands.json|legacy-repeat-11|0|0.248|
|acceptance-commands.json|legacy-repeat-12|0|0.251|
|acceptance-commands.json|legacy-repeat-13|0|0.245|
|acceptance-commands.json|legacy-repeat-14|0|0.228|
|acceptance-commands.json|legacy-repeat-15|0|0.236|
|acceptance-commands.json|legacy-repeat-16|0|0.226|
|acceptance-commands.json|legacy-repeat-17|0|0.241|
|acceptance-commands.json|legacy-repeat-18|0|0.226|
|acceptance-commands.json|legacy-repeat-19|0|0.258|
|acceptance-commands.json|legacy-repeat-20|0|0.248|
|acceptance-commands.json|legacy-client-first|0|0.311|
|acceptance-commands.json|legacy-lost-write|1|0.224|
|artifact-commands.json|artifact-manifest|0|0.137|
|artifact-commands.json|artifact-install|0|2.13|
|artifact-commands.json|artifact-suite|0|1.981|
|dev-commands.json|build|0|4.096|
|dev-commands.json|account-tests|0|1.009|
|dev-commands.json|suite|0|1.886|
|final-artifact-commands.json|final-artifact-install|0|2.034|
|final-artifact-commands.json|final-artifact-suite|0|1.999|
|final-commands.json|final-build|0|4.331|
|final-commands.json|final-suite|0|1.749|
|final-commands.json|browser|1|32.224|
|guard-commands.json|guard-build|0|4.285|
|guard-commands.json|guard-suite|0|1.777|
|initial-commands.json|install|0|2.276|
|initial-commands.json|initial-build|0|4.195|
|release-commands.json|release-build|0|4.216|
|release-commands.json|release-suite|0|1.806|
|release-commands.json|rollback|0|0.153|
|release-commands.json|browser-corrected|0|17.38|
|verified-commands.json|verified-build|0|4.217|
|verified-commands.json|verified-suite|0|1.83|
|verified-commands.json|verified-rollback|0|0.086|
