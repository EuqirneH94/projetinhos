# Reinos de Nexo — etapa 1

Vila procedural, câmera, entrada, movimento com colisões e dois jogadores sincronizados. Sem combate e sem persistência em disco. Requer Node 24.13+ da linha 24.

Extraia em uma pasta separada. No Windows PowerShell local, entre na pasta que contém package.json. Execute:

```powershell
npm.cmd ci
npm.cmd run build
npm.cmd test
npm.cmd run dev
```

Abra http://localhost:5173. Deixe o terminal aberto; Ctrl+C encerra. Para dois jogadores, use duas abas novas com apelidos diferentes. WASD move; mouse direito arrastado gira a câmera; roda dá zoom. Nesta etapa não se reutiliza o banco SQLite da versão final.
