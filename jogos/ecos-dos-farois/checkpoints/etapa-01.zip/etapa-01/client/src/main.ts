import './style.css';
import { SceneView } from './scene.js';
import { Input } from './input.js';
import { Network } from './network.js';
import { UI } from './ui.js';
import { distance, move } from '../../shared/movement.js';
import type { Snapshot } from '../../shared/types.js';
const ui = new UI(document.getElementById('app')!);
let view: SceneView;
try { view = new SceneView(document.getElementById('world') as HTMLCanvasElement); }
catch { document.getElementById('entry-error')!.textContent = 'Seu navegador não iniciou o WebGL. Ative a aceleração de hardware e use Chrome, Edge ou Firefox atual.'; throw new Error('WebGL indisponível'); }
const input = new Input(view.canvas, view), net = new Network();
let local: { x: number; z: number; angle: number } | null = null, selected: string | null = null, seq = 0;
ui.onquality = () => view.quality();
ui.onjoin = name => { local = null; seq = 0; net.connect({ type: 'join', nickname: name }); };
ui.onresume = token => { local = null; seq = 0; net.connect({ type: 'resume', token }); };
ui.onexit = () => { net.disconnect(); input.clear(); sessionStorage.removeItem('nexo.session'); location.reload(); };
net.onnotice = (text, kind) => ui.toast(text, kind);
net.onstatus = (status, text) => { ui.status(status, text); input.enabled = status === 'online'; if (status !== 'online') input.clear(); if (status === 'online') { seq = 0; local = null; view.yaw = 0; } };
net.onstate = (state: Snapshot) => {
  if (!local || distance(local, state.you) > 2 || state.you.dead) local = { x: state.you.x, z: state.you.z, angle: state.you.angle };
  else { local.x += (state.you.x - local.x) * 0.25; local.z += (state.you.z - local.z) * 0.25; }
  ui.update(state, net.rtt);
};
input.onkey = key => { if (key === 'h') ui.help(); if (key === 'escape') { ui.help(false); selected = null; } };
input.onclick = (x, y) => { const hit = view.pick(x, y); if (hit?.kind === 'enemy') selected = hit.id; };
const token = sessionStorage.getItem('nexo.session'); if (token) ui.onresume(token);
let last = performance.now(), sendAt = 0;
function frame(time: number) {
  const dt = Math.min(0.05, (time - last) / 1000); last = time;
  if (net.state && local && input.enabled) {
    const dir = input.direction(view.yaw);
    if (!net.state.you.dead) { move(local, dir.x, dir.z, dt); if (Math.hypot(dir.x, dir.z) > 0) local.angle = Math.atan2(dir.x, dir.z); }
    if (time - sendAt >= 50) { net.send({ type: 'move', seq: seq++, ...dir }); sendAt = time; }
  }
  view.update(net.state, net.interpolated(), local, selected, time / 1000, dt); requestAnimationFrame(frame);
}
requestAnimationFrame(frame);
