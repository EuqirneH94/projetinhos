import type { Snapshot } from '../../shared/types.js';
export const esc = (s: string) => s.replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]!));
export class UI {
  onjoin = (_name: string) => {}; onresume = (_token: string) => {}; onexit = () => {}; onquality = () => false;
  online = false;
  constructor(root: HTMLElement) {
    root.innerHTML = `
    <header class="topbar"><div class="wordmark"><span class="crystal">◆</span> REINOS DE NEXO <span class="build">ALFA 0.1</span></div><div class="top-actions"><button id="quality" title="Alternar sombras e resolução">Qualidade: alta</button><button id="help-button">Controles <kbd>H</kbd></button><button id="exit" hidden>Sair</button></div></header>
    <section id="entry" class="entry"><div class="eyebrow">NEXO FORTE · UM NOVO MUNDO</div><h1>Há caminhos<br>que esperam<br><em>por você.</em></h1><p class="intro">Entre as montanhas e o bosque,<br>uma pequena luz ainda resiste.</p><form id="entry-form" class="entry-card"><span class="eyebrow">SUA JORNADA COMEÇA EM ALVOR</span><label for="nickname">Como devemos chamar você?</label><input id="nickname" maxlength="18" minlength="3" placeholder="Seu apelido no vale" autocomplete="nickname" required pattern="[\p{L}\p{N} _-]{3,18}"><div class="class-choice"><span>⚔</span><div><strong>Guerreiro</strong><small>Aço, coragem e a luz de Alvor.</small></div><span class="class-check">✓</span></div><button class="primary" id="enter" type="submit">Entrar no vale <span>→</span></button><button type="button" id="continue" class="secondary" hidden>Continuar jornada</button><details class="recovery"><summary>Tenho uma chave de retorno</summary><input id="recovery-token" aria-label="Chave de retorno" placeholder="Cole sua chave privada" maxlength="43" autocomplete="off"><button type="button" id="recover">Recuperar viajante</button></details><small class="entry-note">Multiplayer real · Progresso salvo no servidor</small><p id="entry-error" role="status"></p></form></section>
    <div id="hud" hidden><section class="vitals panel"><div class="avatar">⚔<span id="level">1</span></div><div class="vitals-body"><div class="name-row"><strong id="name"></strong><small>GUERREIRO</small></div><div class="bar health"><i id="health-fill"></i><span id="health-text"></span></div><div class="bar energy"><i id="energy-fill"></i><span id="energy-text"></span></div></div></section><aside class="world-info"><div class="zone-label"><span class="eyebrow">TERRAS DE ALVOR</span><h2 id="zone">Vila do Farol</h2><small id="connection">Conectando…</small></div><div class="panel map-wrap"><canvas id="minimap" width="220" height="200" aria-label="Mapa da região"></canvas><span class="map-north">N</span></div></aside><div class="movement-hint panel">W A S D <span>mover</span> · botão direito <span>câmera</span> · roda <span>zoom</span></div><div class="bottom-brand">VALE DE ALVOR <span>·</span> NEXO FORTE TECNOLOGIA</div></div>
    <div id="toasts" aria-live="polite"></div>
    <div id="network-overlay" class="overlay" hidden><div class="modal"><span class="eyebrow">ENTRE DOIS CAMINHOS</span><h2>Retornando ao vale</h2><p id="network-text"></p><button id="network-exit" class="secondary">Voltar à entrada</button></div></div>
    <div id="help" class="overlay" hidden><div class="modal"><span class="eyebrow">GUIA DO VIAJANTE</span><h2>Encontre seu caminho</h2><div class="help-grid"><kbd>W A S D</kbd><span>Mover o guerreiro</span><kbd>Mouse direito</kbd><span>Segurar e arrastar para girar a câmera</span><kbd>Roda</kbd><span>Aproximar ou afastar</span><kbd>H / Esc</kbd><span>Abrir ou fechar esta ajuda</span></div><p>O farol de cristal marca a vila. A estrada ao norte leva ao Bosque do Eco.</p><button id="help-close" class="primary">Voltar à aventura</button></div></div>`;
    document.querySelector('#entry-form')!.addEventListener('submit', e => { e.preventDefault(); const input = this.el<HTMLInputElement>('nickname'); const name = input.value.trim(); if (!/^[\p{L}\p{N} _-]{3,18}$/u.test(name)) { this.el('entry-error').textContent = 'Use de 3 a 18 letras, números, espaços, _ ou -.'; return; } this.onjoin(name); });
    let last: { token: string; nickname: string } | null = null; try { last = JSON.parse(localStorage.getItem('nexo.last') ?? 'null'); } catch {}
    if (last?.token) { this.el('continue').hidden = false; this.el('continue').textContent = `Continuar como ${last.nickname}`; this.el('continue').onclick = () => this.onresume(last!.token); }
    this.el('recover').onclick = () => { const token = this.el<HTMLInputElement>('recovery-token').value.trim(); if (/^[A-Za-z0-9_-]{43}$/.test(token)) this.onresume(token); else this.el('entry-error').textContent = 'A chave precisa ter 43 caracteres.'; };
    this.el('help-button').onclick = () => this.help(); this.el('help-close').onclick = () => this.help(false);
    this.el('quality').onclick = () => { this.el('quality').textContent = this.onquality() ? 'Qualidade: econômica' : 'Qualidade: alta'; };
    this.el('exit').onclick = () => this.onexit(); this.el('network-exit').onclick = () => this.onexit();
  }
  el<E extends HTMLElement = HTMLElement>(id: string) { return document.getElementById(id) as E; }
  help(open = this.el('help').hidden) { this.el('help').hidden = !open; }
  toast(text: string, kind = 'info') { const div = document.createElement('div'); div.className = `toast ${kind}`; div.textContent = text; this.el('toasts').append(div); setTimeout(() => div.remove(), 4200); }
  status(status: string, text = '') {
    if (status === 'online') { this.online = true; this.el('entry').hidden = true; this.el('hud').hidden = false; this.el('exit').hidden = false; this.el('network-overlay').hidden = true; this.el<HTMLButtonElement>('enter').disabled = false; }
    else if (status === 'connecting') { this.el('entry-error').textContent = 'Abrindo os portões…'; this.el<HTMLButtonElement>('enter').disabled = true; }
    else { this.online = false; this.el('network-overlay').hidden = false; this.el('network-text').textContent = text; this.el<HTMLButtonElement>('enter').disabled = false; }
  }
  update(state: Snapshot, rtt: number) {
    const p = state.you; this.el('name').textContent = p.nickname; this.el('level').textContent = String(p.level);
    this.el('health-fill').style.width = `${p.hp / p.maxHp * 100}%`; this.el('health-text').textContent = `${Math.ceil(p.hp)} / ${p.maxHp}`;
    this.el('energy-fill').style.width = `${p.energy}%`; this.el('energy-text').textContent = `${Math.floor(p.energy)} / 100`;
    this.el('zone').textContent = p.z < 0 ? 'Bosque do Eco' : 'Vila do Farol'; this.el('connection').textContent = `● ${state.players.length} viajante${state.players.length > 1 ? 's' : ''} no vale · ${rtt || '…'} ms`;
    this.map(state);
  }
  private map(state: Snapshot) {
    const c = this.el<HTMLCanvasElement>('minimap').getContext('2d')!; c.clearRect(0, 0, 220, 200); c.fillStyle = '#284d44'; c.fillRect(0, 0, 220, 200);
    const x = (v: number) => (v + 44) / 88 * 220, z = (v: number) => (v + 46) / 84 * 200;
    c.fillStyle = '#657c59'; c.fillRect(0, z(0), 220, 200 - z(0)); c.strokeStyle = '#bdaf83'; c.lineWidth = 8; c.beginPath(); c.moveTo(110, 0); c.lineTo(110, 200); c.stroke();
    c.lineWidth = 5; c.beginPath(); c.moveTo(35, z(15)); c.lineTo(185, z(15)); c.stroke();
    c.fillStyle = '#98a988'; for (const [hx, hz] of [[-13, 23], [12, 23], [13, 11], [-15, 2], [27, 21]]) c.fillRect(x(hx) - 7, z(hz) - 5, 14, 10);
    for (const e of state.enemies) if (e.state !== 'dead') { c.fillStyle = '#d68f76'; c.beginPath(); c.arc(x(e.x), z(e.z), 2.5, 0, 7); c.fill(); }
    c.fillStyle = '#f1d394'; c.beginPath(); c.arc(x(-4), z(14), 3, 0, 7); c.fill();
    c.fillStyle = '#8ce0cb'; c.fillRect(x(0) - 3, z(28) - 3, 6, 6);
    for (const p of state.players) { c.fillStyle = p.id === state.you.id ? '#fff0c8' : '#98d6ec'; c.beginPath(); c.arc(x(p.x), z(p.z), p.id === state.you.id ? 4.3 : 3.4, 0, 7); c.fill(); }
  }
}
