import { randomUUID } from 'node:crypto';
import { SPAWN, WORLD } from '../../shared/config.js';
import { move } from '../../shared/movement.js';
import type { ClientMessage, GameEvent, Loot, PlayerSave, PublicEnemy, Self, Snapshot } from '../../shared/types.js';
export type Player = PlayerSave & { input: { x: number; z: number; at: number; seq: number }; lastCombat: number; potionAt: number };
export class Game {
  players = new Map<string, Player>();
  enemies = new Map<string, PublicEnemy>();
  loot = new Map<string, Loot>();
  events: GameEvent[] = [];
  notices: { id: string; text: string; kind: 'info' | 'error' | 'success' }[] = [];
  dirty = new Set<string>();
  tick = 0;
  constructor(public now = () => Date.now()) {}
  create(nickname: string): PlayerSave {
    return { id: randomUUID(), nickname, ...SPAWN, angle: 0, hp: 120, energy: 100, xp: 0, level: 1, coins: 0,
      inventory: [{ item: 'potion', quantity: 3 }], weapon: 'trainingSword', armor: 'tunic',
      quest: { state: 'available', brumino: 0, cerne: 0 }, dead: false, respawnAt: 0,
      cooldowns: { attack: 0, cleave: 0, nova: 0 } };
  }
  connect(saved: PlayerSave): Player {
    const p: Player = { ...structuredClone(saved), input: { x: 0, z: 0, at: 0, seq: -1 }, lastCombat: 0, potionAt: 0 };
    this.players.set(p.id, p); return p;
  }
  save(p: Player): PlayerSave {
    const { input: _i, lastCombat: _c, potionAt: _p, ...saved } = p; return structuredClone(saved);
  }
  hp(p: Player) { return 120 + (p.level - 1) * 24; }
  notice(p: Player, text: string, kind: 'info' | 'error' | 'success' = 'info') { this.notices.push({ id: p.id, text, kind }); }
  action(p: Player, msg: ClientMessage) {
    if (msg.type === 'move' && msg.seq > p.input.seq) p.input = { x: msg.x, z: msg.z, at: this.now(), seq: msg.seq };
  }
  step(dt = 0.05) {
    this.tick++;
    for (const p of this.players.values()) if (!p.dead && this.now() - p.input.at < 250) {
      move(p, p.input.x, p.input.z, dt, WORLD.speed);
      if (Math.hypot(p.input.x, p.input.z) > 0) p.angle = Math.atan2(p.input.x, p.input.z);
    }
  }
  snapshot(id: string, events: GameEvent[] = []): Snapshot {
    const p = this.players.get(id)!;
    const you: Self = { ...this.save(p), maxHp: this.hp(p), maxEnergy: 100, ack: p.input.seq };
    return { type: 'state', time: this.now(), tick: this.tick, you, events,
      players: [...this.players.values()].map(a => ({ id: a.id, nickname: a.nickname, x: a.x, z: a.z,
        angle: a.angle, hp: a.hp, maxHp: this.hp(a), energy: a.energy, level: a.level, dead: a.dead,
        weapon: a.weapon, moving: !a.dead && this.now() - a.input.at < 250 && Math.hypot(a.input.x, a.input.z) > 0 })),
      enemies: [...this.enemies.values()], loot: [...this.loot.values()] };
  }
}
