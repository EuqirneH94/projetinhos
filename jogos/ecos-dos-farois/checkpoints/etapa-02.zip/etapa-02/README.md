# Reinos de Nexo — etapa 2

Combate, inimigos com IA, habilidades, morte e reaparecimento. Coleta, missão, inventário funcional e XP ficam para a etapa seguinte. Sessões apenas em memória.

Extraia em uma pasta separada. No Windows PowerShell local, entre na pasta que contém package.json. Execute:

```powershell
npm.cmd ci
npm.cmd run build
npm.cmd test
npm.cmd run dev
```

Abra http://localhost:5173. Deixe o terminal aberto; Ctrl+C encerra. Para dois jogadores, use duas abas novas com apelidos diferentes. WASD move; mouse direito arrastado gira a câmera; roda dá zoom. Nesta etapa não se reutiliza o banco SQLite da versão final.
