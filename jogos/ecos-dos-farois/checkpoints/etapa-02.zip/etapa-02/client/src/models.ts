import * as T from 'three';
import type { EnemyKind } from '../../shared/types.js';
export function material(color: T.ColorRepresentation, roughness = 0.92) { return new T.MeshStandardMaterial({ color, roughness, flatShading: true }); }
export function mesh(geometry: T.BufferGeometry, mat: T.Material, x = 0, y = 0, z = 0, parent?: T.Object3D) {
  const m = new T.Mesh(geometry, mat); m.position.set(x, y, z); m.castShadow = true; m.receiveShadow = true; parent?.add(m); return m;
}
export const box = (w: number, h: number, d: number, mat: T.Material, x: number, y: number, z: number, parent: T.Object3D) => mesh(new T.BoxGeometry(w, h, d), mat, x, y, z, parent);
export type Actor = { root: T.Group; body: T.Group; left: T.Group; right: T.Group; arm: T.Group; sword?: T.Mesh; label?: T.Sprite; labelKey?: string };
export function warrior(color = 0x346d78, npc = false): Actor {
  const root = new T.Group(), body = new T.Group(); root.add(body);
  const cloth = material(color), leather = material(0x59483d), skin = material(0xd8ac82), metal = material(0xadbcc0, 0.55), gold = material(0xd7ba7e, 0.55);
  box(0.72, 0.68, 0.44, cloth, 0, 1.15, 0, body);
  box(0.76, 0.17, 0.47, leather, 0, 0.84, 0, body);
  box(0.14, 0.15, 0.05, gold, 0, 0.84, 0.26, body);
  mesh(new T.IcosahedronGeometry(0.32, 1), skin, 0, 1.85, 0, body);
  const hair = mesh(new T.SphereGeometry(0.33, 7, 4, 0, Math.PI * 2, 0, Math.PI * 0.58), material(npc ? 0xe4d9ae : 0x443b35), 0, 1.94, -0.02, body);
  hair.rotation.x = -0.12;
  for (const x of [-0.11, 0.11]) box(0.065, 0.065, 0.025, material(0x233a3b), x, 1.87, 0.28, body);
  mesh(new T.DodecahedronGeometry(0.25, 0), metal, -0.47, 1.44, 0, body).scale.set(1.2, 0.65, 1);
  mesh(new T.DodecahedronGeometry(0.25, 0), metal, 0.47, 1.44, 0, body).scale.set(1.2, 0.65, 1);
  const cape = mesh(new T.BoxGeometry(0.67, 0.92, 0.08), material(npc ? 0x9cae83 : 0xb9563f), 0, 1.10, -0.28, body); cape.rotation.x = -0.12;
  const left = new T.Group(), right = new T.Group(); left.position.set(-0.2, 0.8, 0); right.position.set(0.2, 0.8, 0); body.add(left, right);
  for (const leg of [left, right]) { box(0.26, 0.58, 0.29, leather, 0, -0.25, 0, leg); box(0.3, 0.25, 0.4, material(0x343b3c), 0, -0.62, 0.05, leg); }
  const arm = new T.Group(); arm.position.set(-0.5, 1.3, 0); body.add(arm);
  box(0.24, 0.55, 0.24, cloth, 0, -0.21, 0, arm);
  mesh(new T.IcosahedronGeometry(0.14, 0), skin, 0, -0.52, 0.02, arm);
  const sword = box(0.12, 0.95, 0.055, metal, 0, -0.56, 0.5, arm); sword.rotation.x = Math.PI / 2.9;
  box(0.41, 0.08, 0.12, gold, 0, -0.62, 0.14, arm);
  box(0.24, 0.55, 0.25, cloth, 0.5, 1.12, 0, body);
  const shield = mesh(new T.CylinderGeometry(0.39, 0.33, 0.1, 6), material(npc ? 0x7a9970 : 0x36505d), 0.61, 1.0, 0.13, body); shield.rotation.z = Math.PI / 2;
  if (npc) { sword.visible = false; box(0.09, 2.0, 0.09, leather, -0.65, 1.05, 0.1, body); mesh(new T.OctahedronGeometry(0.22), new T.MeshStandardMaterial({ color: 0x90e4c9, emissive: 0x53b7a2, emissiveIntensity: 0.8 }), -0.65, 2.2, 0.1, body); }
  return { root, body, left, right, arm, sword };
}
export function creature(kind: EnemyKind): Actor {
  const root = new T.Group(), body = new T.Group(); root.add(body);
  const left = new T.Group(), right = new T.Group(), arm = new T.Group();
  body.add(left, right, arm);
  if (kind === 'brumino') {
    const fur = material(0x8c6570), dark = material(0x574857), ivory = material(0xe2d5b6);
    mesh(new T.DodecahedronGeometry(0.73, 0), fur, 0, 0.8, 0, body).scale.set(0.85, 0.75, 1.35);
    mesh(new T.DodecahedronGeometry(0.48, 0), fur, 0, 0.81, 0.7, body);
    box(0.52, 0.26, 0.27, dark, 0, 0.67, 1.02, body);
    for (const x of [-0.32, 0.32]) {
      const ear = mesh(new T.ConeGeometry(0.17, 0.39, 3), dark, x, 1.2, 0.63, body); ear.rotation.z = -x;
      const tusk = mesh(new T.ConeGeometry(0.075, 0.31, 5), ivory, x * 0.7, 0.64, 1.12, body); tusk.rotation.x = -0.45;
      mesh(new T.SphereGeometry(0.055, 6, 4), material(0xf2cf6f), x * 0.9, 0.94, 1.0, body);
    }
    left.position.y = right.position.y = 0.6;
    for (const [i, group] of [left, right].entries()) for (const z of [-0.43, 0.45]) box(0.2, 0.57, 0.2, dark, i === 0 ? -0.36 : 0.36, -0.3, z, group);
  } else {
    const wood = material(0x6b7160), moss = material(0x637f62), eyes = new T.MeshStandardMaterial({ color: 0xffd889, emissive: 0xffac49, emissiveIntensity: 0.7 });
    mesh(new T.DodecahedronGeometry(0.77, 0), wood, 0, 1.2, 0, body).scale.set(0.95, 1.3, 0.65);
    mesh(new T.DodecahedronGeometry(0.43, 0), moss, 0, 2.19, 0, body);
    for (const x of [-0.16, 0.16]) box(0.09, 0.12, 0.07, eyes, x, 2.22, 0.34, body);
    left.position.set(-0.34, 0.85, 0); right.position.set(0.34, 0.85, 0);
    for (const g of [left, right]) box(0.37, 0.85, 0.4, wood, 0, -0.4, 0, g);
    for (const x of [-0.88, 0.88]) { mesh(new T.DodecahedronGeometry(0.35), moss, x, 1.65, 0, body); box(0.35, 0.8, 0.4, wood, x, 1.12, 0.1, arm); }
    mesh(new T.OctahedronGeometry(0.15), eyes, 0, 1.35, 0.46, body);
    for (const x of [-0.3, 0.3]) { const branch = mesh(new T.CylinderGeometry(0.06, 0.13, 0.85, 4), wood, x, 2.58, 0, body); branch.rotation.z = x; }
  }
  return { root, body, left, right, arm };
}
export function animate(actor: Actor, moving: boolean, time: number, speed = 1) {
  const walk = moving ? Math.sin(time * 10 * speed) : 0;
  actor.left.rotation.x = walk * 0.55; actor.right.rotation.x = -walk * 0.55;
  actor.arm.rotation.x = -walk * 0.22;
  actor.body.position.y = moving ? Math.abs(walk) * 0.065 : Math.sin(time * 2) * 0.018;
}
export function nameplate(text: string, color = '#f6ecd7', ratio?: number): T.Sprite {
  const canvas = document.createElement('canvas'); canvas.width = 384; canvas.height = 88;
  const c = canvas.getContext('2d')!;
  c.font = '600 27px system-ui'; c.textAlign = 'center'; c.textBaseline = 'middle';
  c.shadowColor = '#0c252b'; c.shadowBlur = 6; c.fillStyle = color; c.fillText(text, 192, 32);
  if (ratio !== undefined) { c.shadowBlur = 0; c.fillStyle = '#182e32df'; c.fillRect(65, 62, 254, 12); c.fillStyle = '#d78173'; c.fillRect(68, 65, 248 * Math.max(0, Math.min(1, ratio)), 6); }
  const sprite = new T.Sprite(new T.SpriteMaterial({ map: new T.CanvasTexture(canvas), depthTest: false, transparent: true })); sprite.scale.set(3.8, 0.87, 1); return sprite;
}
export function disposeLabel(label: T.Sprite) { (label.material as T.SpriteMaterial).map?.dispose(); label.material.dispose(); }
