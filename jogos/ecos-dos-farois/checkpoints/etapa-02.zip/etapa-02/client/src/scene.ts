import * as T from 'three';
import type { PublicEnemy, PublicPlayer, Snapshot } from '../../shared/types.js';
import { ITEMS, NPC } from '../../shared/config.js';
import { animate, creature, disposeLabel, material, mesh, nameplate, type Actor, warrior } from './models.js';
import { scenery } from './scenery.js';
export type Pick = { kind: 'enemy' | 'npc' | 'loot'; id: string };
export class SceneView {
  scene = new T.Scene(); camera = new T.PerspectiveCamera(48, 1, 0.1, 240); renderer: T.WebGLRenderer;
  yaw = 0; pitch = 0.66; zoom = 15; target = new T.Vector3(0, 1.3, 19);
  private players = new Map<string, Actor>(); private enemies = new Map<string, Actor>();
  private loot = new Map<string, T.Group>(); private ray = new T.Raycaster(); private scenery;
  private ring: T.Mesh; private effects: { root: T.Object3D; at: number; type: string }[] = [];
  private lastEvents = -1;
  private sun: T.DirectionalLight; economical = false;
  constructor(public canvas: HTMLCanvasElement) {
    this.renderer = new T.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
    this.renderer.setPixelRatio(Math.min(devicePixelRatio, 1.6)); this.renderer.shadowMap.enabled = true; this.renderer.shadowMap.type = T.PCFSoftShadowMap;
    this.renderer.outputColorSpace = T.SRGBColorSpace; this.renderer.toneMapping = T.ACESFilmicToneMapping; this.renderer.toneMappingExposure = 1.2;
    this.scene.background = new T.Color(0xb9d6cf); this.scene.fog = new T.Fog(0xb9d6cf, 44, 133);
    this.scene.add(new T.HemisphereLight(0xd7efed, 0x63744a, 2.25));
    this.sun = new T.DirectionalLight(0xffe3ac, 3.2); this.sun.position.set(-30, 50, 15); this.sun.castShadow = true;
    this.sun.shadow.mapSize.set(2048, 2048); const s = this.sun.shadow.camera; s.left = -43; s.right = 43; s.top = 43; s.bottom = -43; s.far = 150; this.sun.shadow.bias = -0.0005; this.sun.shadow.normalBias = 0.03; this.scene.add(this.sun, this.sun.target);
    this.scenery = scenery(this.scene);
    this.ring = new T.Mesh(new T.RingGeometry(0.95, 1.05, 48), new T.MeshBasicMaterial({ color: 0xf2c97e, transparent: true, opacity: 0.9, depthWrite: false, side: T.DoubleSide })); this.ring.rotation.x = -Math.PI / 2; this.ring.visible = false; this.scene.add(this.ring);
    this.resize(); window.addEventListener('resize', () => this.resize());
  }
  resize() { this.renderer.setSize(innerWidth, innerHeight); this.camera.aspect = innerWidth / innerHeight; this.camera.updateProjectionMatrix(); }
  quality() { this.economical = !this.economical; this.renderer.setPixelRatio(this.economical ? 1 : Math.min(devicePixelRatio, 1.6)); this.renderer.shadowMap.enabled = !this.economical; this.resize(); return this.economical; }
  orbit(dx: number, dy: number) { this.yaw -= dx * 0.005; this.pitch = T.MathUtils.clamp(this.pitch + dy * 0.004, 0.32, 1.18); }
  zoomBy(delta: number) { this.zoom = T.MathUtils.clamp(this.zoom + delta * 0.014, 6.3, 26); }
  pick(x: number, y: number): Pick | null {
    const rect = this.canvas.getBoundingClientRect(); this.ray.setFromCamera(new T.Vector2((x - rect.left) / rect.width * 2 - 1, -(y - rect.top) / rect.height * 2 + 1), this.camera);
    const roots: T.Object3D[] = [...this.scenery.interactive, ...[...this.enemies.values()].filter(a => a.root.visible).map(a => a.root), ...this.loot.values()];
    for (const hit of this.ray.intersectObjects(roots, true)) { let o: T.Object3D | null = hit.object; while (o) { if (o.userData.kind) return o.userData as Pick; o = o.parent; } }
    return null;
  }
  update(state: Snapshot | null, render: { players: PublicPlayer[]; enemies: PublicEnemy[] } | null, local: { x: number; z: number; angle: number } | null, selected: string | null, time: number, dt: number) {
    this.scenery.animate(time); animate(this.scenery.npc, false, time);
    if (state && render) {
      const active = new Set<string>();
      for (const p of render.players) {
        active.add(p.id); let actor = this.players.get(p.id);
        if (!actor) { actor = warrior(p.id === state.you.id ? 0x346d78 : 0x6c668d); this.players.set(p.id, actor); this.scene.add(actor.root); actor.label = nameplate(p.nickname, p.id === state.you.id ? '#e8ddbc' : '#a5e0d3'); actor.label.position.y = 2.8; actor.root.add(actor.label); }
        const pos = p.id === state.you.id && local ? local : p;
        actor.root.position.set(pos.x, p.dead ? -0.7 : 0, pos.z); actor.root.rotation.y = pos.angle; actor.body.rotation.z = p.dead ? -1.3 : 0;
        animate(actor, p.moving && !p.dead, time); if (actor.sword) (actor.sword.material as T.MeshStandardMaterial).color.setHex(p.weapon === 'dawnSword' ? 0xf1d18d : p.weapon === 'forestBlade' ? 0x85c3ae : 0xadbcc0);
      }
      for (const [id, a] of this.players) if (!active.has(id)) { this.scene.remove(a.root); this.players.delete(id); this.disposeActor(a); }
      const mobs = new Set<string>();
      for (const e of render.enemies) {
        mobs.add(e.id); let a = this.enemies.get(e.id);
        if (!a) { a = creature(e.kind); a.root.userData = { kind: 'enemy', id: e.id }; this.enemies.set(e.id, a); this.scene.add(a.root); }
        a.root.visible = e.state !== 'dead'; a.root.position.set(e.x, 0, e.z); a.root.rotation.y = e.angle;
        animate(a, e.state === 'patrol' || e.state === 'chase' || e.state === 'return', time, e.kind === 'cerne' ? 0.65 : 1);
        const key = `${e.hp}/${e.maxHp}`;
        if (a.labelKey !== key) { if (a.label) { a.root.remove(a.label); disposeLabel(a.label); } a.label = nameplate(e.kind === 'brumino' ? 'Brumino' : 'Cerne errante', '#edc2b4', e.hp / e.maxHp); a.label.position.y = e.kind === 'brumino' ? 1.9 : 3.2; a.root.add(a.label); a.labelKey = key; }
      }
      for (const [id, a] of this.enemies) if (!mobs.has(id)) { this.scene.remove(a.root); this.enemies.delete(id); this.disposeActor(a); }
      const drops = new Set(state.loot.map(l => l.id));
      for (const l of state.loot) {
        let g = this.loot.get(l.id);
        if (!g) { g = new T.Group(); g.userData = { kind: 'loot', id: l.id }; mesh(new T.OctahedronGeometry(0.27), new T.MeshStandardMaterial({ color: l.ownerId === state.you.id ? 0xf9d590 : 0x96aaa4, emissive: 0xb68c3a, emissiveIntensity: l.ownerId === state.you.id ? 0.5 : 0.05 }), 0, 0, 0, g); const marker = nameplate(l.ownerId === state.you.id ? '◆ Recompensa · F' : 'Outro viajante', l.ownerId === state.you.id ? '#f7d791' : '#b4c7c0'); marker.position.y = 0.8; marker.scale.multiplyScalar(0.7); g.add(marker); this.loot.set(l.id, g); this.scene.add(g); }
        g.position.set(l.x, 0.55 + Math.sin(time * 2.5) * 0.13, l.z); g.rotation.y = time * 0.65;
      }
      for (const [id, g] of this.loot) if (!drops.has(id)) { this.scene.remove(g); g.traverse(o => { if (o instanceof T.Mesh) { o.geometry.dispose(); if (o.material instanceof T.Material) o.material.dispose(); } if (o instanceof T.Sprite) disposeLabel(o); }); this.loot.delete(id); }
      const enemy = state.enemies.find(e => e.id === selected && e.state !== 'dead'); this.ring.visible = !!enemy;
      if (enemy) { const pos = render.enemies.find(e => e.id === enemy.id) ?? enemy; this.ring.position.set(pos.x, 0.05, pos.z); }
      if (state.tick !== this.lastEvents) { this.lastEvents = state.tick; for (const e of state.events) {
        if (e.kind === 'hit' || e.kind === 'heal') { const label = nameplate(`${e.kind === 'heal' ? '+' : '−'}${e.amount}`, e.kind === 'heal' ? '#9af0be' : '#ffe1af'); label.scale.multiplyScalar(0.7); label.position.set(e.x, 2.4, e.z); this.scene.add(label); this.effects.push({ root: label, at: time, type: 'text' }); }
        else if (e.kind === 'nova' || e.kind === 'slash' || e.kind === 'level') { const ring = new T.Mesh(new T.TorusGeometry(e.kind === 'nova' ? 1.7 : 0.8, 0.065, 5, 32, e.kind === 'slash' ? Math.PI * 1.4 : Math.PI * 2), new T.MeshBasicMaterial({ color: e.kind === 'level' ? 0xffdc8d : 0x9ee3d3, transparent: true })); ring.rotation.x = Math.PI / 2; ring.position.set(e.x, 0.8, e.z); this.scene.add(ring); this.effects.push({ root: ring, at: time, type: 'ring' }); }
      } }
      if (local) this.target.lerp(new T.Vector3(local.x, 1.4, local.z), 1 - Math.exp(-dt * 10));
    } else {
      this.target.set(0, 1.5, 17); this.yaw = -0.35 + Math.sin(time * 0.04) * 0.08;
    }
    for (let i = this.effects.length - 1; i >= 0; i--) { const fx = this.effects[i], age = time - fx.at; if (fx.type === 'text') fx.root.position.y += dt * 1.2; else fx.root.scale.setScalar(1 + age * 1.8); const mat = (fx.root as T.Mesh).material as T.Material & { opacity: number }; mat.opacity = Math.max(0, 1 - age / 0.85); if (age > 0.85) { this.scene.remove(fx.root); if (fx.root instanceof T.Sprite) disposeLabel(fx.root); else { (fx.root as T.Mesh).geometry.dispose(); mat.dispose(); } this.effects.splice(i, 1); } }
    const horizontal = Math.cos(this.pitch) * this.zoom;
    const desired = new T.Vector3(this.target.x + Math.sin(this.yaw) * horizontal, this.target.y + Math.sin(this.pitch) * this.zoom, this.target.z + Math.cos(this.yaw) * horizontal);
    // Laços da câmera recuam antes de atravessar casas: caixas são suficientes para este mapa compacto.
    this.camera.position.copy(desired); this.camera.lookAt(this.target);
    this.sun.position.set(this.target.x - 30, 50, this.target.z + 15); this.sun.target.position.copy(this.target); this.sun.target.updateMatrixWorld();
    this.renderer.render(this.scene, this.camera);
  }
  private disposeActor(a: Actor) { a.root.traverse(o => { if (o instanceof T.Mesh) { o.geometry.dispose(); const mats = Array.isArray(o.material) ? o.material : [o.material]; mats.forEach(m => m.dispose()); } if (o instanceof T.Sprite) disposeLabel(o); }); }
}
