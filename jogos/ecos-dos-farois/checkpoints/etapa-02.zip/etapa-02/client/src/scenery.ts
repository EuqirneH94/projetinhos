import * as T from 'three';
import { HOUSES, NPC, seeded, SHRINE, TREES } from '../../shared/config.js';
import { box, material, mesh, nameplate, warrior } from './models.js';
export function scenery(scene: T.Scene) {
  const random = seeded(47), groundMat = new T.MeshStandardMaterial({ vertexColors: true, roughness: 1 });
  const terrain = new T.PlaneGeometry(125, 125, 55, 55); terrain.rotateX(-Math.PI / 2);
  const colors: number[] = [], position = terrain.attributes.position;
  const green = new T.Color(), warm = new T.Color(0x95aa7c), cool = new T.Color(0x496d63);
  for (let i = 0; i < position.count; i++) {
    const z = position.getZ(i); green.copy(warm).lerp(cool, T.MathUtils.clamp((-z + 8) / 75, 0, 1)); green.multiplyScalar(0.92 + random() * 0.13); colors.push(green.r, green.g, green.b);
  }
  terrain.setAttribute('color', new T.Float32BufferAttribute(colors, 3)); mesh(terrain, groundMat, 0, -0.04, 0, scene).castShadow = false;
  const road = material(0xc9bc96);
  const trail = mesh(new T.PlaneGeometry(4.8, 79), road, 0, 0.011, -3, scene); trail.rotation.x = -Math.PI / 2; trail.castShadow = false;
  const square = mesh(new T.CircleGeometry(11.5, 28), road, 0, 0.015, 18, scene); square.rotation.x = -Math.PI / 2; square.castShadow = false;
  const crossing = mesh(new T.PlaneGeometry(52, 3.1), road, 0, 0.018, 15, scene); crossing.rotation.x = -Math.PI / 2; crossing.castShadow = false;
  for (const h of HOUSES) {
    const g = new T.Group(); g.position.set(h.x, 0, h.z); scene.add(g);
    const timber = material(0x605248), walls = material(h.color), roof = material(h.roof);
    box(h.w + 0.35, 0.42, h.d + 0.35, material(0x7c8173), 0, 0.2, 0, g);
    box(h.w, 3.7, h.d, walls, 0, 2.1, 0, g);
    for (const x of [-h.w / 2, h.w / 2]) for (const z of [-h.d / 2, h.d / 2]) box(0.25, 3.8, 0.25, timber, x, 2.2, z, g);
    box(h.w + 0.2, 0.18, h.d + 0.2, timber, 0, 3.8, 0, g);
    const roofShape = new T.Shape(); roofShape.moveTo(-h.w / 2 - 0.55, 0); roofShape.lineTo(0, 2.45); roofShape.lineTo(h.w / 2 + 0.55, 0); roofShape.closePath();
    const roofMesh = mesh(new T.ExtrudeGeometry(roofShape, { depth: h.d + 0.9, bevelEnabled: false }), roof, 0, 3.9, -h.d / 2 - 0.45, g);
    roofMesh.receiveShadow = true;
    box(1.25, 2.3, 0.12, timber, 0, 1.55, h.d / 2 + 0.06, g);
    const glass = new T.MeshStandardMaterial({ color: 0xffdb8e, emissive: 0xefba62, emissiveIntensity: 0.3 });
    for (const x of [-h.w * 0.3, h.w * 0.3]) {
      box(1.15, 1.2, 0.14, timber, x, 2.35, h.d / 2 + 0.08, g);
      box(0.83, 0.9, 0.16, glass, x, 2.35, h.d / 2 + 0.1, g);
      box(0.09, 0.95, 0.17, timber, x, 2.35, h.d / 2 + 0.14, g);
    }
    box(0.9, 2.6, 0.9, material(0x8b8a7c), h.w * 0.26, 5.1, -h.d * 0.2, g);
    for (let i = 0; i < 3; i++) box(1.7, 0.2, 0.65, material(0x939a89), 0, 0.1 + i * 0.1, h.d / 2 + 0.55 + (2 - i) * 0.4, g);
  }
  const trunk = new T.InstancedMesh(new T.CylinderGeometry(0.19, 0.34, 3, 6), material(0x6a5846), TREES.length);
  const crown1 = new T.InstancedMesh(new T.DodecahedronGeometry(1.65, 0), material(0x5b8c72), TREES.length);
  const crown2 = new T.InstancedMesh(new T.DodecahedronGeometry(1.4, 0), material(0x7aa076), TREES.length);
  const dummy = new T.Object3D();
  TREES.forEach((t, i) => {
    dummy.position.set(t.x, t.scale * 1.5, t.z); dummy.scale.setScalar(t.scale); dummy.rotation.set(0, i, 0); dummy.updateMatrix(); trunk.setMatrixAt(i, dummy.matrix);
    dummy.position.y = 3.8 * t.scale; dummy.scale.set(t.scale, t.scale * 1.18, t.scale); dummy.updateMatrix(); crown1.setMatrixAt(i, dummy.matrix);
    dummy.position.set(t.x + 0.65 * t.scale, 4.3 * t.scale, t.z - 0.35); dummy.scale.setScalar(t.scale); dummy.updateMatrix(); crown2.setMatrixAt(i, dummy.matrix);
    const shade = new T.Color([0x62917a, 0x587f6e, 0x799d75][t.type]); crown1.setColorAt(i, shade);
  });
  for (const inst of [trunk, crown1, crown2]) { inst.castShadow = true; inst.receiveShadow = true; scene.add(inst); }
  const grass = new T.InstancedMesh(new T.ConeGeometry(0.09, 0.45, 3), material(0x81a578), 1050);
  const flowers = new T.InstancedMesh(new T.IcosahedronGeometry(0.095, 0), material(0xdcc496), 260);
  let gi = 0, fi = 0;
  while (gi < 1050) {
    const x = random() * 86 - 43, z = random() * 81 - 44;
    if (Math.abs(x) < 3.5 || (z > -1 && Math.abs(x) < 30)) continue;
    dummy.position.set(x, 0.12, z); dummy.scale.set(1, 0.6 + random(), 1); dummy.rotation.y = random() * 6; dummy.updateMatrix(); grass.setMatrixAt(gi++, dummy.matrix);
    if (fi < 260) { dummy.position.y = 0.33; dummy.scale.setScalar(1); dummy.updateMatrix(); flowers.setMatrixAt(fi, dummy.matrix); flowers.setColorAt(fi++, new T.Color([0xb8add4, 0xead3a1, 0xc5d5a1][fi % 3])); }
  }
  scene.add(grass, flowers);
  for (let i = 0; i < 14; i++) {
    const x = -90 + i * 14, z = -77 - random() * 22, h = 18 + random() * 25;
    const mountain = mesh(new T.ConeGeometry(17 + random() * 11, h, 5), material(i % 2 ? 0x759497 : 0x8ba5a0), x, h / 2 - 3, z, scene); mountain.rotation.y = random() * 4;
    const cap = mesh(new T.ConeGeometry(5.5, h * 0.32, 5), material(0xcedbd0), x, h * 0.83 - 3, z, scene); cap.rotation.y = mountain.rotation.y;
    mountain.castShadow = cap.castShadow = false;
  }
  for (const p of [{ x: -25, z: 14, s: 2 }, { x: 31, z: -31, s: 2 }, { x: -31, z: -28, s: 1.7 }]) {
    mesh(new T.DodecahedronGeometry(p.s, 0), material(0x8d9b8d), p.x, p.s * 0.5, p.z, scene).scale.y = 0.8;
  }
  // O Farol de Alvor é o marco da vila e o ponto de recuperação de vida.
  const shrine = new T.Group(); shrine.position.set(SHRINE.x, 0, SHRINE.z); scene.add(shrine);
  const stone = material(0xacb7a4);
  mesh(new T.CylinderGeometry(1.65, 1.95, 0.4, 8), stone, 0, 0.2, 0, shrine);
  mesh(new T.CylinderGeometry(1.1, 1.45, 0.9, 6), stone, 0, 0.75, 0, shrine);
  const crystal = mesh(new T.OctahedronGeometry(0.93), new T.MeshStandardMaterial({ color: 0xace9d2, emissive: 0x5cc1aa, emissiveIntensity: 0.9, roughness: 0.25, metalness: 0.15 }), 0, 2.65, 0, shrine); crystal.scale.y = 1.65;
  const orbit = mesh(new T.TorusGeometry(1.4, 0.055, 6, 40), material(0xd6bf82, 0.4), 0, 2.6, 0, shrine); orbit.rotation.x = Math.PI / 2.5;
  const beacon = new T.PointLight(0x8de6c6, 10, 15, 2); beacon.position.set(SHRINE.x, 3.5, SHRINE.z); scene.add(beacon);
  const shrineLabel = nameplate('FAROL DE ALVOR', '#e2d8b3'); shrineLabel.position.set(SHRINE.x, 5, SHRINE.z); scene.add(shrineLabel);
  const npc = warrior(0x617b62, true); npc.root.position.set(NPC.x, 0, NPC.z); npc.root.rotation.y = 0.6; npc.root.userData = { kind: 'npc', id: 'maera' }; scene.add(npc.root);
  const npcLabel = nameplate('◆ Maera · Guardiã', '#edcf85'); npcLabel.position.y = 2.8; npc.root.add(npcLabel);
  const sign = new T.Group(); sign.position.set(3.5, 0, 3); scene.add(sign);
  box(0.16, 2.3, 0.16, material(0x665442), 0, 1.15, 0, sign);
  const board = box(2.2, 0.6, 0.16, material(0x74614b), 0, 1.9, 0, sign); board.rotation.z = 0.07;
  const signLabel = nameplate('↑ BOSQUE DO ECO', '#f0dfb9'); signLabel.position.y = 2.6; signLabel.scale.multiplyScalar(0.65); sign.add(signLabel);
  // Tecido simples e cabos são originais e se movem sem assets externos.
  const flags: T.Mesh[] = [];
  for (const x of [-4.3, 4.3]) {
    box(0.13, 4.5, 0.13, material(0x665442), x, 2.25, 0, scene);
    const flag = mesh(new T.BoxGeometry(0.95, 1.5, 0.06), material(0xb95e45), x + 0.43, 3.4, 0, scene); flags.push(flag);
    mesh(new T.OctahedronGeometry(0.16), material(0xe2c78c), x, 4.65, 0, scene);
  }
  const motesG = new T.BufferGeometry(); const points: number[] = [];
  for (let i = 0; i < 95; i++) points.push((random() - 0.5) * 64, 0.6 + random() * 3, -random() * 42);
  motesG.setAttribute('position', new T.Float32BufferAttribute(points, 3));
  const motes = new T.Points(motesG, new T.PointsMaterial({ color: 0xf9e7a0, size: 0.075, transparent: true, opacity: 0.65, depthWrite: false })); scene.add(motes);
  return { npc, interactive: [npc.root], animate(time: number) { crystal.rotation.y = time * 0.3; crystal.position.y = 2.65 + Math.sin(time * 1.3) * 0.12; orbit.rotation.z = time * 0.15; motes.position.y = Math.sin(time * 0.45) * 0.18; motes.rotation.y = Math.sin(time * 0.09) * 0.025; flags.forEach((f, i) => { f.rotation.y = Math.sin(time * 2 + i) * 0.12; }); } };
}
