import { randomUUID } from 'node:crypto';
import { ENEMY_SPAWNS, ENEMY_TYPES, ITEMS, SKILLS, SHRINE, SPAWN, WORLD } from '../../shared/config.js';
import { distance, move } from '../../shared/movement.js';
import type { ClientMessage, GameEvent, Loot, PlayerSave, PublicEnemy, Self, SkillId, Snapshot } from '../../shared/types.js';
export type Player = PlayerSave & { input: { x: number; z: number; at: number; seq: number }; lastCombat: number; potionAt: number };
export type Enemy = PublicEnemy & { home: { x: number; z: number }; target?: string; attackAt: number; respawnAt: number; cycle: number; participants: Map<string, number>; seed: number };
export class Game {
  players = new Map<string, Player>();
  enemies = new Map<string, Enemy>();
  loot = new Map<string, Loot>();
  events: GameEvent[] = [];
  notices: { id: string; text: string; kind: 'info' | 'error' | 'success' }[] = [];
  dirty = new Set<string>();
  tick = 0;
  constructor(public now = () => Date.now()) {
    ENEMY_SPAWNS.forEach((s, i) => this.enemies.set(s.id, { ...s, angle: 0, hp: ENEMY_TYPES[s.kind].hp,
      maxHp: ENEMY_TYPES[s.kind].hp, state: 'patrol', home: { x: s.x, z: s.z }, attackAt: 0,
      respawnAt: 0, cycle: 0, participants: new Map(), seed: i * 1.7 }));
  }
  create(nickname: string): PlayerSave {
    return { id: randomUUID(), nickname, ...SPAWN, angle: 0, hp: 120, energy: 100, xp: 0, level: 1, coins: 0,
      inventory: [{ item: 'potion', quantity: 3 }], weapon: 'trainingSword', armor: 'tunic',
      quest: { state: 'available', brumino: 0, cerne: 0 }, dead: false, respawnAt: 0,
      cooldowns: { attack: 0, cleave: 0, nova: 0 } };
  }
  connect(saved: PlayerSave): Player {
    const p: Player = { ...structuredClone(saved), input: { x: 0, z: 0, at: 0, seq: -1 }, lastCombat: 0, potionAt: 0 };
    this.players.set(p.id, p); return p;
  }
  save(p: Player): PlayerSave {
    const { input: _i, lastCombat: _c, potionAt: _p, ...saved } = p; return structuredClone(saved);
  }
  hp(p: Player) { return 120 + (p.level - 1) * 24; }
  notice(p: Player, text: string, kind: 'info' | 'error' | 'success' = 'info') { this.notices.push({ id: p.id, text, kind }); }
  action(p: Player, msg: ClientMessage) {
    if (msg.type === 'move') { if (msg.seq > p.input.seq) p.input = { x: msg.x, z: msg.z, at: this.now(), seq: msg.seq }; return; }
    if (msg.type === 'respawn') {
      if (!p.dead || this.now() < p.respawnAt) { this.notice(p, 'Aguarde a luz do farol para retornar.', 'error'); return; }
      p.dead = false; p.x = SPAWN.x; p.z = SPAWN.z; p.hp = this.hp(p); p.energy = 100; p.input.x = p.input.z = 0;
      this.dirty.add(p.id); this.notice(p, 'O Farol de Alvor acolhe você novamente.', 'success'); return;
    }
    if (p.dead) { this.notice(p, 'Retorne ao farol antes de agir.', 'error'); return; }
    if (msg.type === 'skill') this.skill(p, msg.skill, msg.target);
  }
  step(dt = 0.05) {
    this.tick++;
    dt = Math.max(0, Math.min(0.05, dt));
    const now = this.now();
    for (const p of this.players.values()) if (!p.dead) {
      if (now - p.input.at < 250) { move(p, p.input.x, p.input.z, dt, WORLD.speed); if (Math.hypot(p.input.x, p.input.z) > 0) p.angle = Math.atan2(p.input.x, p.input.z); }
      p.energy = Math.min(100, p.energy + 12 * dt);
      if (distance(p, SHRINE) < 7 && now - p.lastCombat > 4000) p.hp = Math.min(this.hp(p), p.hp + 18 * dt);
    }
    for (const e of this.enemies.values()) this.enemyStep(e, dt, now);
    for (const [id, l] of this.loot) if (now > l.expiresAt) this.loot.delete(id);
  }
  private skill(p: Player, skill: SkillId, target?: string) {
    const s = SKILLS[skill], now = this.now();
    if (p.cooldowns[skill] > now) { this.notice(p, 'A habilidade ainda está recarregando.', 'error'); return; }
    if (p.energy < s.cost) { this.notice(p, 'Energia insuficiente.', 'error'); return; }
    const targets: Enemy[] = [];
    if (skill === 'nova') {
      for (const e of this.enemies.values()) if (e.state !== 'dead' && e.state !== 'return' && distance(p, e) <= s.range) targets.push(e);
      if (!targets.length) { this.notice(p, 'Nenhum inimigo ao alcance do círculo.', 'error'); return; }
    } else {
      const e = target ? this.enemies.get(target) : undefined;
      if (!e || e.state === 'dead') { this.notice(p, 'Selecione um inimigo vivo com um clique ou toque.', 'error'); return; }
      if (e.state === 'return') { this.notice(p, 'Esse inimigo está retornando à origem.', 'error'); return; }
      if (distance(p, e) > s.range) { this.notice(p, 'Chegue mais perto do alvo.', 'error'); return; }
      targets.push(e); p.angle = Math.atan2(e.x - p.x, e.z - p.z);
    }
    p.energy -= s.cost; p.cooldowns[skill] = now + s.cooldown; p.lastCombat = now; this.dirty.add(p.id);
    this.events.push({ kind: skill === 'nova' ? 'nova' : 'slash', x: p.x, z: p.z, sourceId: p.id });
    const damage = s.damage + (p.level - 1) * 4 + ITEMS[p.weapon].value;
    for (const e of targets) {
      const actual = Math.min(damage, e.hp); e.hp -= actual; e.participants.set(p.id, (e.participants.get(p.id) ?? 0) + actual);
      if (!e.target || !this.players.has(e.target)) { e.target = p.id; e.attackAt = now + 650; }
      e.state = 'chase'; this.events.push({ kind: 'hit', x: e.x, z: e.z, amount: actual, targetId: e.id, sourceId: p.id });
      if (e.hp <= 0) this.kill(e);
    }
  }
  private kill(e: Enemy) {
    if (e.state === 'dead') return;
    e.hp = 0; e.state = 'dead'; e.target = undefined; e.respawnAt = this.now() + 22000; e.cycle++;
    const eligible = [...e.participants.entries()].map(([id, damage]) => ({ p: this.players.get(id), damage }))
      .filter((v): v is { p: Player; damage: number } => !!v.p && !v.p.dead && distance(v.p, e) <= 18)
      .sort((a, b) => b.damage - a.damage || a.p.id.localeCompare(b.p.id));
    for (const { p } of eligible) this.rewardKill(p, e);
    if (eligible[0]) {
      const l: Loot = { id: randomUUID(), x: e.x, z: e.z, ownerId: eligible[0].p.id, coins: ENEMY_TYPES[e.kind].coins,
        item: e.kind === 'cerne' && e.cycle % 2 === 1 ? 'barkArmor' : e.kind === 'brumino' && e.cycle % 4 === 0 ? 'forestBlade' : 'potion', expiresAt: this.now() + 60000 };
      this.loot.set(l.id, l); this.notice(eligible[0].p, 'Uma recompensa caiu no chão. Aproxime-se e pressione F.');
    }
    e.participants.clear(); this.events.push({ kind: 'death', x: e.x, z: e.z, targetId: e.id });
  }
  private rewardKill(p: Player, e: Enemy) { this.notice(p, `${ENEMY_TYPES[e.kind].name} abatido.`, 'success'); }
  private enemyStep(e: Enemy, dt: number, now: number) {
    const spec = ENEMY_TYPES[e.kind];
    if (e.state === 'dead') { if (now >= e.respawnAt) { e.x = e.home.x; e.z = e.home.z; e.hp = e.maxHp; e.state = 'patrol'; e.participants.clear(); } else return; }
    let p = e.target ? this.players.get(e.target) : undefined;
    if (e.state !== 'return' && (!p || p.dead || p.z > 1 || distance(p, e.home) > 15 || distance(e, e.home) > 12)) {
      if (e.target) { e.state = 'return'; e.target = undefined; e.participants.clear(); p = undefined; }
    }
    if (e.state === 'return') {
      if (distance(e, e.home) < 0.45) { e.x = e.home.x; e.z = e.home.z; e.hp = e.maxHp; e.state = 'patrol'; }
      else this.walkEnemy(e, e.home, spec.speed * 1.3, dt);
      return;
    }
    if (!p || p.dead) {
      p = [...this.players.values()].filter(a => !a.dead && a.z <= 1 && distance(a, e.home) <= 15 && distance(a, e) < spec.aggro).sort((a, b) => distance(a, e) - distance(b, e))[0];
      if (p) { e.target = p.id; e.attackAt = now + 650; e.state = 'chase'; }
    }
    if (p && !p.dead) {
      e.angle = Math.atan2(p.x - e.x, p.z - e.z);
      if (distance(e, p) > spec.range) { e.state = 'chase'; this.walkEnemy(e, p, spec.speed, dt); }
      else {
        e.state = 'attack';
        if (now >= e.attackAt) {
          e.attackAt = now + spec.interval; const damage = Math.max(1, spec.damage - ITEMS[p.armor].value);
          p.hp = Math.max(0, p.hp - damage); p.lastCombat = now; this.dirty.add(p.id);
          this.events.push({ kind: 'hit', x: p.x, z: p.z, amount: damage, targetId: p.id, sourceId: e.id });
          if (p.hp <= 0) { p.dead = true; p.respawnAt = now + 3000; p.input.x = p.input.z = 0; this.events.push({ kind: 'death', x: p.x, z: p.z, targetId: p.id }); this.notice(p, 'Sua jornada continua. A luz do farol permitirá seu retorno.'); }
        }
      }
    } else {
      e.state = 'patrol'; const dest = { x: e.home.x + Math.cos(now / 6200 + e.seed) * 2.2, z: e.home.z + Math.sin(now / 6200 + e.seed) * 2.2 };
      this.walkEnemy(e, dest, 0.9, dt);
    }
  }
  private walkEnemy(e: Enemy, target: { x: number; z: number }, speed: number, dt: number) {
    const d = distance(e, target); if (d < 0.08) return;
    const x = (target.x - e.x) / d, z = (target.z - e.z) / d; e.angle = Math.atan2(x, z); move(e, x, z, dt, Math.min(speed, d / Math.max(dt, 0.001)), e.kind === 'cerne' ? 0.52 : 0.4);
  }
  snapshot(id: string, events: GameEvent[] = []): Snapshot {
    const p = this.players.get(id)!;
    const you: Self = { ...this.save(p), maxHp: this.hp(p), maxEnergy: 100, ack: p.input.seq };
    return { type: 'state', time: this.now(), tick: this.tick, you, events,
      players: [...this.players.values()].map(a => ({ id: a.id, nickname: a.nickname, x: a.x, z: a.z,
        angle: a.angle, hp: a.hp, maxHp: this.hp(a), energy: a.energy, level: a.level, dead: a.dead,
        weapon: a.weapon, moving: !a.dead && this.now() - a.input.at < 250 && Math.hypot(a.input.x, a.input.z) > 0 })),
      enemies: [...this.enemies.values()].map(e => ({ id: e.id, kind: e.kind, x: e.x, z: e.z, angle: e.angle, hp: e.hp, maxHp: e.maxHp, state: e.state })), loot: [...this.loot.values()] };
  }
}
