import { createGameServer } from './server.js';
const port = Number(process.env.PORT ?? 8787);
if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error('PORT inválida.');
const server = await createGameServer({ port, host: process.env.HOST ?? '127.0.0.1' });
console.log(`Reinos de Nexo • servidor em http://${process.env.HOST ?? '127.0.0.1'}:${server.port}`);
let closing = false;
async function close() { if (closing) return; closing = true; await server.close(); process.exit(0); }
process.on('SIGINT', close); process.on('SIGTERM', close);
