import type { ClientMessage } from '../../shared/types.js';
const exact = (o: Record<string, unknown>, keys: string[]) => Object.keys(o).every(k => keys.includes(k));
const finite = (v: unknown): v is number => typeof v === 'number' && Number.isFinite(v);
const id = (v: unknown): v is string => typeof v === 'string' && /^[a-zA-Z0-9_-]{1,80}$/.test(v);
export function parseMessage(raw: string): ClientMessage | null {
  if (Buffer.byteLength(raw, 'utf8') > 512) return null;
  let o: Record<string, unknown>;
  try { o = JSON.parse(raw); } catch { return null; }
  if (!o || Array.isArray(o) || typeof o !== 'object') return null;
  switch (o.type) {
    case 'join': return exact(o, ['type', 'nickname']) && typeof o.nickname === 'string' &&
      /^[\p{L}\p{N} _-]{3,18}$/u.test(o.nickname) && o.nickname.trim() === o.nickname && o.nickname.trim().length >= 3 ? o as ClientMessage : null;
    case 'resume': return exact(o, ['type', 'token']) && typeof o.token === 'string' && /^[A-Za-z0-9_-]{43}$/.test(o.token) ? o as ClientMessage : null;
    case 'move': return exact(o, ['type', 'seq', 'x', 'z']) && Number.isSafeInteger(o.seq) && (o.seq as number) >= 0 &&
      finite(o.x) && finite(o.z) && Math.abs(o.x) <= 1 && Math.abs(o.z) <= 1 ? o as ClientMessage : null;
    case 'skill': return exact(o, ['type', 'skill', 'target']) && ['attack', 'cleave', 'nova'].includes(o.skill as string) &&
      (o.target === undefined || id(o.target)) ? o as ClientMessage : null;
    case 'quest': return exact(o, ['type', 'action']) && ['accept', 'complete'].includes(o.action as string) ? o as ClientMessage : null;
    case 'loot': return exact(o, ['type', 'id']) && id(o.id) ? o as ClientMessage : null;
    case 'item': return exact(o, ['type', 'action', 'slot']) && ['use', 'equip', 'discard'].includes(o.action as string) &&
      Number.isInteger(o.slot) && (o.slot as number) >= 0 && (o.slot as number) < 10 ? o as ClientMessage : null;
    case 'respawn': return exact(o, ['type']) ? o as ClientMessage : null;
    case 'ping': return exact(o, ['type', 'at']) && finite(o.at) && o.at > 0 && o.at < 1e15 ? o as ClientMessage : null;
    default: return null;
  }
}
