import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { resolve, extname, sep } from 'node:path';
import { WebSocketServer, WebSocket } from 'ws';
import { Game } from './game.js';
import { Store } from './store.js';
import { parseMessage } from './protocol.js';
import type { ServerMessage } from '../../shared/types.js';
type Connection = { ws: WebSocket; id?: string; tokens: number; refill: number; invalid: number; alive: boolean };
export async function createGameServer(options: { port?: number; host?: string; store?: Store; origins?: string[] } = {}) {
  const game = new Game(), store = options.store ?? new Store();
  const connections = new Set<Connection>();
  const owners = new Map<string, Connection>();
  const root = resolve(process.cwd(), 'client/dist');
  const origins = new Set(options.origins ?? (process.env.ALLOWED_ORIGINS?.split(',') ?? ['http://localhost:5173', 'http://127.0.0.1:5173', 'http://localhost:8787', 'http://127.0.0.1:8787']));
  const http = createServer(async (req, res) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Referrer-Policy', 'no-referrer');
    res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; font-src 'self'; object-src 'none'; frame-ancestors 'none'");
    if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405).end(); return; }
    if (req.url === '/health') { res.setHeader('Content-Type', 'application/json'); res.end(JSON.stringify({ ok: true, players: game.players.size, tick: game.tick })); return; }
    try {
      const pathname = decodeURIComponent(new URL(req.url ?? '/', 'http://localhost').pathname);
      const file = resolve(root, '.' + (pathname === '/' ? '/index.html' : pathname));
      if (!file.startsWith(root + sep)) { res.writeHead(403).end(); return; }
      const body = await readFile(file);
      const mime: Record<string, string> = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon' };
      res.setHeader('Content-Type', mime[extname(file)] ?? 'application/octet-stream');
      res.setHeader('Cache-Control', extname(file) === '.html' ? 'no-store' : 'public, max-age=3600');
      res.end(req.method === 'HEAD' ? undefined : body);
    } catch { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }).end('Arquivo não encontrado. Execute npm run build na raiz do projeto.'); }
  });
  const wss = new WebSocketServer({ noServer: true, maxPayload: 1024, perMessageDeflate: false });
  http.on('upgrade', (req, socket, head) => {
    if (req.url !== '/ws' || connections.size >= 32 || (req.headers.origin && !origins.has(req.headers.origin))) { socket.write('HTTP/1.1 403 Forbidden\r\nConnection: close\r\n\r\n'); socket.destroy(); return; }
    wss.handleUpgrade(req, socket, head, ws => wss.emit('connection', ws, req));
  });
  const send = (c: Connection, msg: ServerMessage) => {
    if (c.ws.readyState === WebSocket.OPEN && c.ws.bufferedAmount < 262144) c.ws.send(JSON.stringify(msg));
    else if (c.ws.bufferedAmount >= 262144) c.ws.close(1013, 'Conexão lenta');
  };
  wss.on('connection', ws => {
    const c: Connection = { ws, tokens: 70, refill: Date.now(), invalid: 0, alive: true }; connections.add(c);
    const timeout = setTimeout(() => { if (!c.id) ws.close(1008, 'Entrada expirada'); }, 5000);
    ws.on('pong', () => { c.alive = true; });
    ws.on('error', () => {});
    ws.on('message', (data, binary) => {
      const now = Date.now(); c.tokens = Math.min(70, c.tokens + (now - c.refill) * 0.045); c.refill = now;
      if (--c.tokens < 0) { ws.close(1008, 'Muitas ações'); return; }
      const msg = binary ? null : parseMessage(data.toString());
      if (!msg) { send(c, { type: 'notice', text: 'Ação inválida rejeitada pelo servidor.', kind: 'error' }); if (++c.invalid >= 4) ws.close(1008, 'Mensagens inválidas'); return; }
      if (msg.type === 'join' || msg.type === 'resume') {
        if (c.id) { send(c, { type: 'notice', kind: 'error', text: 'Esta conexão já tem um personagem.' }); return; }
        const saved = msg.type === 'join' ? game.create(msg.nickname) : store.resume(msg.token);
        if (!saved) { send(c, { type: 'notice', kind: 'error', text: 'Chave inválida ou expirada. Crie um viajante ou confira sua chave.' }); ws.close(4003, 'Sessão inválida'); return; }
        const existing = owners.get(saved.id);
        if (existing) { const p = game.players.get(saved.id); if (p) store.save(game.save(p)); existing.ws.close(4001, 'Sessão aberta em outra aba'); }
        const latest = msg.type === 'resume' ? store.resume(msg.token)! : saved;
        const token = msg.type === 'join' ? store.create(saved) : msg.token;
        game.connect(latest); c.id = saved.id; owners.set(c.id, c); clearTimeout(timeout);
        send(c, { type: 'welcome', id: c.id, token, nickname: saved.nickname }); send(c, game.snapshot(c.id)); return;
      }
      if (!c.id || owners.get(c.id) !== c) { send(c, { type: 'notice', kind: 'error', text: 'Entre no mundo antes de enviar ações.' }); return; }
      if (msg.type === 'ping') { send(c, { type: 'pong', at: msg.at }); return; }
      const p = game.players.get(c.id); if (p) game.action(p, msg);
    });
    ws.on('close', () => {
      clearTimeout(timeout); connections.delete(c);
      if (c.id && owners.get(c.id) === c) { const p = game.players.get(c.id); if (p) store.save(game.save(p)); game.players.delete(c.id); owners.delete(c.id); }
    });
  });
  const tick = setInterval(() => {
    game.step();
    for (const id of game.dirty) { const p = game.players.get(id); if (p) store.save(game.save(p)); } game.dirty.clear();
    if (game.tick % 2 === 0) {
      const events = game.events.splice(0);
      for (const c of connections) if (c.id && owners.get(c.id) === c) send(c, game.snapshot(c.id, events));
    }
    for (const n of game.notices.splice(0)) { const c = owners.get(n.id); if (c) send(c, { type: 'notice', text: n.text, kind: n.kind }); }
    if (game.tick % 100 === 0) for (const p of game.players.values()) store.save(game.save(p));
  }, 50);
  const heartbeat = setInterval(() => { for (const c of connections) { if (!c.alive) c.ws.terminate(); else { c.alive = false; c.ws.ping(); } } }, 15000);
  await new Promise<void>((ok, fail) => { http.once('error', fail); http.listen(options.port ?? 8787, options.host ?? '127.0.0.1', () => { http.off('error', fail); ok(); }); });
  const address = http.address(); const port = typeof address === 'object' && address ? address.port : 8787;
  return { game, store, port, http, async close() {
    clearInterval(tick); clearInterval(heartbeat);
    for (const p of game.players.values()) store.save(game.save(p));
    for (const c of connections) c.ws.terminate();
    await new Promise<void>(ok => wss.close(() => ok()));
    await new Promise<void>(ok => http.close(() => ok())); store.close();
  } };
}
