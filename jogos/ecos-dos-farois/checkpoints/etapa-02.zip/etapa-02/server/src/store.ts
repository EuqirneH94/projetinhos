import { createHash, randomBytes } from 'node:crypto';
import type { PlayerSave } from '../../shared/types.js';
export const digest = (token: string) => createHash('sha256').update(token).digest('hex');
export class Store {
  saves = new Map<string, PlayerSave>();
  sessions = new Map<string, string>();
  save(p: PlayerSave) { this.saves.set(p.id, structuredClone(p)); }
  create(p: PlayerSave) { const token = randomBytes(32).toString('base64url'); this.save(p); this.sessions.set(digest(token), p.id); return token; }
  resume(token: string) { const id = this.sessions.get(digest(token)); return id ? structuredClone(this.saves.get(id)) : undefined; }
  close() {}
}
