export type EnemyKind = 'brumino' | 'cerne';
export type SkillId = 'attack' | 'cleave' | 'nova';
export type ItemId = 'trainingSword' | 'tunic' | 'potion' | 'dawnSword' | 'barkArmor' | 'forestBlade';
export type InventorySlot = { item: ItemId; quantity: number };
export type Quest = { state: 'available' | 'active' | 'ready' | 'completed'; brumino: number; cerne: number };
export type PlayerSave = {
  id: string; nickname: string; x: number; z: number; angle: number;
  hp: number; energy: number; xp: number; level: number; coins: number;
  inventory: InventorySlot[]; weapon: ItemId; armor: ItemId; quest: Quest;
  dead: boolean; respawnAt: number; cooldowns: Record<SkillId, number>;
};
export type PublicPlayer = { id: string; nickname: string; x: number; z: number; angle: number;
  hp: number; maxHp: number; energy: number; level: number; dead: boolean; weapon: ItemId; moving: boolean };
export type Self = PlayerSave & { maxHp: number; maxEnergy: number; ack: number };
export type EnemyState = 'patrol' | 'chase' | 'attack' | 'return' | 'dead';
export type PublicEnemy = { id: string; kind: EnemyKind; x: number; z: number; angle: number;
  hp: number; maxHp: number; state: EnemyState };
export type Loot = { id: string; x: number; z: number; ownerId: string; coins: number;
  item: ItemId; expiresAt: number };
export type GameEvent = { kind: 'hit' | 'heal' | 'death' | 'level' | 'nova' | 'slash';
  x: number; z: number; amount?: number; targetId?: string; sourceId?: string };
export type Snapshot = { type: 'state'; time: number; tick: number; players: PublicPlayer[];
  enemies: PublicEnemy[]; loot: Loot[]; you: Self; events: GameEvent[] };
export type ClientMessage =
  | { type: 'join'; nickname: string }
  | { type: 'resume'; token: string }
  | { type: 'move'; seq: number; x: number; z: number }
  | { type: 'skill'; skill: SkillId; target?: string }
  | { type: 'quest'; action: 'accept' | 'complete' }
  | { type: 'loot'; id: string }
  | { type: 'item'; action: 'use' | 'equip' | 'discard'; slot: number }
  | { type: 'respawn' }
  | { type: 'ping'; at: number };
export type ServerMessage = Snapshot
  | { type: 'welcome'; id: string; token: string; nickname: string }
  | { type: 'notice'; text: string; kind: 'info' | 'error' | 'success' }
  | { type: 'pong'; at: number };
