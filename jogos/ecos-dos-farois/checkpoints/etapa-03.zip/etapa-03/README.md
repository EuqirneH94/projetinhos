# Reinos de Nexo — etapa 3

Missão, XP até nível 5, mochila, moedas, equipamento, poções e saque. Sessões ainda são mantidas na memória do servidor e desaparecem ao encerrá-lo.

Extraia em uma pasta separada. No Windows PowerShell local, entre na pasta que contém package.json. Execute:

```powershell
npm.cmd ci
npm.cmd run build
npm.cmd test
npm.cmd run dev
```

Abra http://localhost:5173. Deixe o terminal aberto; Ctrl+C encerra. Para dois jogadores, use duas abas novas com apelidos diferentes. WASD move; mouse direito arrastado gira a câmera; roda dá zoom. Nesta etapa não se reutiliza o banco SQLite da versão final.
